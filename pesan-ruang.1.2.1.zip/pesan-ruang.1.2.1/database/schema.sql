-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'siswa') NOT NULL DEFAULT 'siswa',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
);

-- Create rooms table
CREATE TABLE IF NOT EXISTS rooms (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    type ENUM('kelas', 'lab') NOT NULL,
    capacity INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_id INT NOT NULL,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    purpose VARCHAR(255) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE RESTRICT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_room_date (room_id, date),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
);

-- Insert sample data
-- Password: admin123 (bcrypt hashed)
INSERT IGNORE INTO users (name, email, password, role) VALUES 
('Admin Campus', 'admin@campus.edu', '$2a$10$zmqVjLkiwCOH2adDGU/mceefcnaXUgPv6fgYm56r1T9e45WQV3DAy', 'admin'),
('Siswa Demo', 'siswa@campus.edu', '$2a$10$j4uGl1ZqMU48AGkoM/WWk.ERZGpEHGMPqvN7RtG1r3tKru0KnbSUi', 'siswa');

INSERT INTO rooms (name, type, capacity, is_active) VALUES 
('Ruang A101', 'kelas', 40, TRUE),
('Ruang A102', 'kelas', 35, TRUE),
('Lab Komputer 1', 'lab', 30, TRUE),
('Lab Fisika 1', 'lab', 25, TRUE);
