package services

import (
	"fmt"
	"pesan-ruang/models"
	"pesan-ruang/repository"
	"golang.org/x/crypto/bcrypt"
)

// AuthService handles authentication logic
type AuthService struct {
	userRepo *repository.UserRepository
}

// NewAuthService creates a new auth service
func NewAuthService(userRepo *repository.UserRepository) *AuthService {
	return &AuthService{userRepo: userRepo}
}

// Login authenticates a user
func (s *AuthService) Login(email, password string) (*models.User, error) {
	if email == "" || password == "" {
		return nil, fmt.Errorf("email and password required")
	}

	user, err := s.userRepo.GetUserByEmail(email)
	if err != nil {
		return nil, fmt.Errorf("invalid email or password")
	}

	// Compare password with bcrypt hash
	err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password))
	if err != nil {
		return nil, fmt.Errorf("invalid email or password")
	}

	if !user.IsActive {
		return nil, fmt.Errorf("user account is inactive")
	}

	return user, nil
}

// Register creates a new user account
func (s *AuthService) Register(name, email, password, role string) (*models.User, error) {
	// Validate input
	if name == "" || email == "" || password == "" {
		return nil, fmt.Errorf("name, email, and password required")
	}

	if len(password) < 6 {
		return nil, fmt.Errorf("password must be at least 6 characters")
	}

	// Default role to siswa if not provided
	if role == "" {
		role = "siswa"
	}

	// Check if email already exists
	existing, _ := s.userRepo.GetUserByEmail(email)
	if existing != nil {
		return nil, fmt.Errorf("email already registered")
	}

	// Create new user
	// Hash password with bcrypt
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, fmt.Errorf("failed to hash password: %w", err)
	}

	user := &models.User{
		Name:     name,
		Email:    email,
		Password: string(hashedPassword),
		Role:     role,
		IsActive: true,
	}

	id, err := s.userRepo.CreateUser(user)
	if err != nil {
		return nil, fmt.Errorf("failed to create user: %w", err)
	}

	user.ID = id
	return user, nil
}
