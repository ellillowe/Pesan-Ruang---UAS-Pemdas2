package services

import (
	"fmt"
	"pesan-ruang/models"
	"pesan-ruang/repository"
)

// RoomService handles business logic for rooms
type RoomService struct {
	roomRepo    *repository.RoomRepository
	bookingRepo *repository.BookingRepository
}

// NewRoomService creates a new room service
func NewRoomService(roomRepo *repository.RoomRepository, bookingRepo *repository.BookingRepository) *RoomService {
	return &RoomService{
		roomRepo:    roomRepo,
		bookingRepo: bookingRepo,
	}
}

// CreateRoom creates a new room
func (s *RoomService) CreateRoom(room *models.Room) (int, error) {
	if room.Name == "" || room.Type == "" || room.Capacity <= 0 {
		return 0, fmt.Errorf("invalid room data")
	}

	if room.Type != "kelas" && room.Type != "lab" {
		return 0, fmt.Errorf("room type must be 'kelas' or 'lab'")
	}

	room.IsActive = true
	return s.roomRepo.CreateRoom(room)
}

// GetAllRooms retrieves all rooms
func (s *RoomService) GetAllRooms() ([]models.Room, error) {
	return s.roomRepo.GetAllRooms()
}

// GetRoomByID retrieves a room by ID
func (s *RoomService) GetRoomByID(id int) (*models.Room, error) {
	return s.roomRepo.GetRoomByID(id)
}

// UpdateRoom updates room information
func (s *RoomService) UpdateRoom(room *models.Room) error {
	if room.ID <= 0 || room.Name == "" || room.Type == "" || room.Capacity <= 0 {
		return fmt.Errorf("invalid room data")
	}

	if room.Type != "kelas" && room.Type != "lab" {
		return fmt.Errorf("room type must be 'kelas' or 'lab'")
	}

	return s.roomRepo.UpdateRoom(room)
}

// DeleteRoom deletes a room only if it has no active bookings
func (s *RoomService) DeleteRoom(id int) error {
	return s.roomRepo.DeleteRoom(id)
}
