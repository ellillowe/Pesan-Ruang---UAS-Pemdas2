package services

import (
	"testing"
)

// TestAuthServiceLoginValidation tests login email and password validation
func TestAuthServiceLoginValidation(t *testing.T) {
	tests := []struct {
		name      string
		email     string
		password  string
		shouldErr bool
	}{
		{
			name:      "Empty email",
			email:     "",
			password:  "password123",
			shouldErr: true,
		},
		{
			name:      "Empty password",
			email:     "user@test.com",
			password:  "",
			shouldErr: true,
		},
		{
			name:      "Both empty",
			email:     "",
			password:  "",
			shouldErr: true,
		},
		{
			name:      "Valid email and password",
			email:     "user@test.com",
			password:  "password123",
			shouldErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Validate email and password are not empty
			isValid := tt.email != "" && tt.password != ""

			if isValid == tt.shouldErr {
				t.Errorf("validation failed: expected error=%v, got valid=%v", tt.shouldErr, isValid)
			}
		})
	}
}

// TestAuthServiceRegisterValidation tests registration input validation
func TestAuthServiceRegisterValidation(t *testing.T) {
	tests := []struct {
		name      string
		name_     string
		email     string
		password  string
		role      string
		shouldErr bool
	}{
		{
			name:      "All fields valid",
			name_:     "John Doe",
			email:     "john@test.com",
			password:  "password123",
			role:      "siswa",
			shouldErr: false,
		},
		{
			name:      "Empty name",
			name_:     "",
			email:     "john@test.com",
			password:  "password123",
			role:      "siswa",
			shouldErr: true,
		},
		{
			name:      "Empty email",
			name_:     "John Doe",
			email:     "",
			password:  "password123",
			role:      "siswa",
			shouldErr: true,
		},
		{
			name:      "Empty password",
			name_:     "John Doe",
			email:     "john@test.com",
			password:  "",
			role:      "siswa",
			shouldErr: true,
		},
		{
			name:      "Password too short",
			name_:     "John Doe",
			email:     "john@test.com",
			password:  "pass",
			role:      "siswa",
			shouldErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Validate required fields
			isValid := tt.name_ != "" &&
				tt.email != "" &&
				len(tt.password) >= 6

			if isValid == tt.shouldErr {
				t.Errorf("validation failed: expected error=%v, got valid=%v", tt.shouldErr, isValid)
			}
		})
	}
}

// TestPasswordLength tests password minimum length requirement
func TestPasswordLength(t *testing.T) {
	tests := []struct {
		name     string
		password string
		valid    bool
	}{
		{"Password 6 chars", "test12", true},
		{"Password 10 chars", "password10", true},
		{"Password 5 chars", "test1", false},
		{"Password 0 chars", "", false},
		{"Password 1 char", "t", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			isValid := len(tt.password) >= 6
			if isValid != tt.valid {
				t.Errorf("password length %d: expected valid=%v, got %v", len(tt.password), tt.valid, isValid)
			}
		})
	}
}

// TestEmailValidation tests email field validation
func TestEmailValidation(t *testing.T) {
	tests := []struct {
		name  string
		email string
		valid bool
	}{
		{"Valid email", "user@test.com", true},
		{"Valid email domain", "admin@company.id", true},
		{"Empty email", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			isValid := tt.email != ""
			if isValid != tt.valid {
				t.Errorf("email '%s': expected valid=%v, got %v", tt.email, tt.valid, isValid)
			}
		})
	}
}
