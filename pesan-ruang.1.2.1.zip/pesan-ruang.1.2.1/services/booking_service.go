package services

import (
	"fmt"
	"pesan-ruang/models"
	"pesan-ruang/repository"
	"time"
)

// BookingService handles business logic for bookings
type BookingService struct {
	bookingRepo *repository.BookingRepository
	roomRepo    *repository.RoomRepository
}

// NewBookingService creates a new booking service
func NewBookingService(bookingRepo *repository.BookingRepository, roomRepo *repository.RoomRepository) *BookingService {
	return &BookingService{
		bookingRepo: bookingRepo,
		roomRepo:    roomRepo,
	}
}

// GetAllBookings retrieves all bookings
func (s *BookingService) GetAllBookings() ([]models.Booking, error) {
	return s.bookingRepo.GetAllBookings()
}

// CreateBooking creates a new booking with conflict checking
func (s *BookingService) CreateBooking(booking *models.Booking) (int, error) {
	// Validate input
	if booking.RoomID <= 0 || booking.UserID <= 0 {
		return 0, fmt.Errorf("invalid room or user ID")
	}

	// Check if room exists and is active
	room, err := s.roomRepo.GetRoomByID(booking.RoomID)
	if err != nil {
		return 0, fmt.Errorf("room not found: %w", err)
	}

	if !room.IsActive {
		return 0, fmt.Errorf("room is not active")
	}

	// Parse date to validate format
	_, err = time.Parse("2006-01-02", booking.Date)
	if err != nil {
		return 0, fmt.Errorf("invalid date format, use YYYY-MM-DD: %w", err)
	}

	// Get all existing bookings for this room and date
	existingBookings, err := s.bookingRepo.GetBookingsByRoomAndDate(booking.RoomID, booking.Date)
	if err != nil {
		return 0, fmt.Errorf("failed to check existing bookings: %w", err)
	}

	// Check for conflicts
	if s.HasTimeConflict(existingBookings, booking) {
		return 0, fmt.Errorf("booking time conflicts with existing booking")
	}

	// Set default status
	if booking.Status == "" {
		booking.Status = "pending"
	}

	return s.bookingRepo.CreateBooking(booking)
}

// HasTimeConflict checks if a new booking conflicts with existing bookings
func (s *BookingService) HasTimeConflict(existingBookings []models.Booking, newBooking *models.Booking) bool {
	for _, existing := range existingBookings {
		// Only check against approved or pending bookings
		if existing.Status == "rejected" {
			continue
		}

		// Parse times
		existingStart, _ := time.Parse("15:04", existing.StartTime)
		existingEnd, _ := time.Parse("15:04", existing.EndTime)
		newStart, _ := time.Parse("15:04", newBooking.StartTime)
		newEnd, _ := time.Parse("15:04", newBooking.EndTime)

		// Check for overlap
		// Conflict if: new start < existing end AND new end > existing start
		if newStart.Before(existingEnd) && newEnd.After(existingStart) {
			return true
		}
	}
	return false
}

// ApproveBooking approves a pending booking
func (s *BookingService) ApproveBooking(bookingID int) error {
	booking, err := s.bookingRepo.GetBookingByID(bookingID)
	if err != nil {
		return fmt.Errorf("booking not found: %w", err)
	}

	if booking.Status != "pending" {
		return fmt.Errorf("can only approve pending bookings")
	}

	// Get all existing bookings for this room and date (excluding this booking)
	existingBookings, err := s.bookingRepo.GetBookingsByRoomAndDate(booking.RoomID, booking.Date)
	if err != nil {
		return fmt.Errorf("failed to check existing bookings: %w", err)
	}

	// Filter out the current booking and rejected ones
	var activeBookings []models.Booking
	for _, b := range existingBookings {
		if b.ID != bookingID && b.Status != "rejected" {
			activeBookings = append(activeBookings, b)
		}
	}

	// Check for conflicts
	if s.HasTimeConflict(activeBookings, booking) {
		return fmt.Errorf("cannot approve: booking time conflicts with existing booking")
	}

	return s.bookingRepo.UpdateBookingStatus(bookingID, "approved")
}

// RejectBooking rejects a booking
func (s *BookingService) RejectBooking(bookingID int) error {
	booking, err := s.bookingRepo.GetBookingByID(bookingID)
	if err != nil {
		return fmt.Errorf("booking not found: %w", err)
	}

	if booking.Status == "rejected" {
		return fmt.Errorf("booking is already rejected")
	}

	if booking.Status == "approved" {
		return fmt.Errorf("cannot reject already approved booking")
	}

	return s.bookingRepo.UpdateBookingStatus(bookingID, "rejected")
}

// CalculateTotalHours calculates the total hours from start_time to end_time
func (s *BookingService) CalculateTotalHours(startTime, endTime string) (float64, error) {
	// Try parsing with seconds first (15:04:05), then without (15:04)
	start, err := time.Parse("15:04:05", startTime)
	if err != nil {
		start, err = time.Parse("15:04", startTime)
		if err != nil {
			return 0, fmt.Errorf("invalid start time format: %w", err)
		}
	}

	end, err := time.Parse("15:04:05", endTime)
	if err != nil {
		end, err = time.Parse("15:04", endTime)
		if err != nil {
			return 0, fmt.Errorf("invalid end time format: %w", err)
		}
	}

	// If end time is before start time, assume it's the next day
	if end.Before(start) {
		end = end.Add(24 * time.Hour)
	}

	duration := end.Sub(start)
	hours := duration.Hours()

	return hours, nil
}

// ReportSummary represents room usage summary
type ReportSummary struct {
	RoomName            string `json:"room_name"`
	TotalBookings       int    `json:"total_bookings"`
	TotalWaktuPemesanan string `json:"total_waktu_pemesanan"`
}

// FormatHoursToWaktu converts decimal hours to "X jam Y menit" format
func FormatHoursToWaktu(hours float64) string {
	totalMinutes := int(hours * 60)
	jam := totalMinutes / 60
	menit := totalMinutes % 60

	if jam == 0 {
		return fmt.Sprintf("%d menit", menit)
	}
	if menit == 0 {
		return fmt.Sprintf("%d jam", jam)
	}
	return fmt.Sprintf("%d jam %d menit", jam, menit)
}

// GetReportSummary returns a summary of room usage for a specific month
func (s *BookingService) GetReportSummary(year, month int) ([]ReportSummary, error) {
	bookings, err := s.bookingRepo.GetAllBookings()
	if err != nil {
		return nil, err
	}

	// Filter bookings by month and year
	var monthBookings []models.Booking
	for _, b := range bookings {
		if b.Status == "rejected" {
			continue
		}
		bookingDate, err := time.Parse("2006-01-02", b.Date)
		if err != nil {
			continue
		}
		if bookingDate.Year() == year && int(bookingDate.Month()) == month {
			monthBookings = append(monthBookings, b)
		}
	}

	// Calculate summary by room
	roomSummary := make(map[int]*ReportSummary)
	roomTotalHours := make(map[int]float64) // Store raw hours for calculation

	for _, booking := range monthBookings {
		room, err := s.roomRepo.GetRoomByID(booking.RoomID)
		if err != nil {
			continue
		}

		hours, err := s.CalculateTotalHours(booking.StartTime, booking.EndTime)
		if err != nil {
			continue
		}

		if _, exists := roomSummary[booking.RoomID]; !exists {
			roomSummary[booking.RoomID] = &ReportSummary{
				RoomName: room.Name,
			}
		}

		roomSummary[booking.RoomID].TotalBookings++
		roomTotalHours[booking.RoomID] += hours
	}

	// Format hours to "X jam Y menit" for each room
	for roomID, summary := range roomSummary {
		summary.TotalWaktuPemesanan = FormatHoursToWaktu(roomTotalHours[roomID])
	}
	var result []ReportSummary
	for _, summary := range roomSummary {
		result = append(result, *summary)
	}

	return result, nil
}
