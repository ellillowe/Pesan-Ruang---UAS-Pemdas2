package services

import (
	"pesan-ruang/models"
	"testing"
)

// TestHasTimeConflict tests the conflict detection logic
func TestHasTimeConflict(t *testing.T) {
	tests := []struct {
		name             string
		existingBookings []models.Booking
		newBooking       *models.Booking
		expected         bool
	}{
		{
			name: "No conflict - different time slots",
			existingBookings: []models.Booking{
				{ID: 1, StartTime: "08:00", EndTime: "09:00", Status: "approved"},
			},
			newBooking: &models.Booking{StartTime: "10:00", EndTime: "11:00"},
			expected:   false,
		},
		{
			name: "Conflict - overlapping times",
			existingBookings: []models.Booking{
				{ID: 1, StartTime: "08:00", EndTime: "09:00", Status: "approved"},
			},
			newBooking: &models.Booking{StartTime: "08:30", EndTime: "09:30"},
			expected:   true,
		},
		{
			name: "No conflict - rejected booking",
			existingBookings: []models.Booking{
				{ID: 1, StartTime: "08:00", EndTime: "09:00", Status: "rejected"},
			},
			newBooking: &models.Booking{StartTime: "08:30", EndTime: "09:30"},
			expected:   false,
		},
		{
			name: "No conflict - exact boundary",
			existingBookings: []models.Booking{
				{ID: 1, StartTime: "08:00", EndTime: "09:00", Status: "approved"},
			},
			newBooking: &models.Booking{StartTime: "09:00", EndTime: "10:00"},
			expected:   false,
		},
		{
			name: "Conflict - new booking completely overlaps",
			existingBookings: []models.Booking{
				{ID: 1, StartTime: "08:00", EndTime: "12:00", Status: "approved"},
			},
			newBooking: &models.Booking{StartTime: "09:00", EndTime: "11:00"},
			expected:   true,
		},
	}

	service := &BookingService{}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := service.HasTimeConflict(tt.existingBookings, tt.newBooking)
			if result != tt.expected {
				t.Errorf("got %v, want %v", result, tt.expected)
			}
		})
	}
}

// TestCalculateTotalHours tests the hour calculation logic
func TestCalculateTotalHours(t *testing.T) {
	tests := []struct {
		name      string
		startTime string
		endTime   string
		expected  float64
		shouldErr bool
	}{
		{
			name:      "Simple 1 hour calculation",
			startTime: "08:00",
			endTime:   "09:00",
			expected:  1.0,
			shouldErr: false,
		},
		{
			name:      "Half hour calculation",
			startTime: "08:00",
			endTime:   "08:30",
			expected:  0.5,
			shouldErr: false,
		},
		{
			name:      "Multiple hours calculation",
			startTime: "08:00",
			endTime:   "12:30",
			expected:  4.5,
			shouldErr: false,
		},
		{
			name:      "Invalid start time format",
			startTime: "25:00",
			endTime:   "09:00",
			expected:  0,
			shouldErr: true,
		},
		{
			name:      "Invalid end time format",
			startTime: "08:00",
			endTime:   "25:00",
			expected:  0,
			shouldErr: true,
		},
	}

	service := &BookingService{}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := service.CalculateTotalHours(tt.startTime, tt.endTime)
			if (err != nil) != tt.shouldErr {
				t.Errorf("error occurred: %v, expected error: %v", err, tt.shouldErr)
			}
			if !tt.shouldErr && result != tt.expected {
				t.Errorf("got %v, want %v", result, tt.expected)
			}
		})
	}
}

// TestCalculateTotalHoursEdgeCases tests edge cases for hour calculation
func TestCalculateTotalHoursEdgeCases(t *testing.T) {
	tests := []struct {
		name      string
		startTime string
		endTime   string
		expected  float64
	}{
		{
			name:      "Quarter hour",
			startTime: "08:00",
			endTime:   "08:15",
			expected:  0.25,
		},
		{
			name:      "45 minutes",
			startTime: "08:00",
			endTime:   "08:45",
			expected:  0.75,
		},
		{
			name:      "Full day 8 hours",
			startTime: "08:00",
			endTime:   "16:00",
			expected:  8.0,
		},
	}

	service := &BookingService{}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := service.CalculateTotalHours(tt.startTime, tt.endTime)
			if err != nil {
				t.Errorf("unexpected error: %v", err)
			}
			if result != tt.expected {
				t.Errorf("got %v, want %v", result, tt.expected)
			}
		})
	}
}
