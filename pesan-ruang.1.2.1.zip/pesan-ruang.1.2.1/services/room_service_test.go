package services

import (
	"testing"
)

// TestRoomServiceValidation tests room creation validation
func TestRoomServiceValidation(t *testing.T) {
	tests := []struct {
		name      string
		roomName  string
		roomType  string
		capacity  int
		shouldErr bool
	}{
		{
			name:      "Valid kelas room",
			roomName:  "Ruang A101",
			roomType:  "kelas",
			capacity:  40,
			shouldErr: false,
		},
		{
			name:      "Valid lab room",
			roomName:  "Lab Komputer 1",
			roomType:  "lab",
			capacity:  30,
			shouldErr: false,
		},
		{
			name:      "Invalid room type",
			roomName:  "Ruang A102",
			roomType:  "invalid",
			capacity:  40,
			shouldErr: true,
		},
		{
			name:      "Invalid capacity",
			roomName:  "Ruang A103",
			roomType:  "kelas",
			capacity:  0,
			shouldErr: true,
		},
		{
			name:      "Empty room name",
			roomName:  "",
			roomType:  "kelas",
			capacity:  40,
			shouldErr: true,
		},
	}

	// Note: In a real scenario, we would use mock repositories
	// This test demonstrates the validation logic
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			isValid := tt.roomName != "" && 
				(tt.roomType == "kelas" || tt.roomType == "lab") && 
				tt.capacity > 0

			if isValid == tt.shouldErr {
				t.Errorf("validation failed for %s", tt.name)
			}
		})
	}
}
