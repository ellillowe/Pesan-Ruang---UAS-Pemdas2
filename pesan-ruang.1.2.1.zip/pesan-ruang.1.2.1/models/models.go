package models

import "time"

// User represents a user in the system
type User struct {
	ID       int       `json:"id"`
	Name     string    `json:"name"`
	Email    string    `json:"email"`
	Password string    `json:"-"` // never expose password
	Role     string    `json:"role"` // admin or siswa
	IsActive bool      `json:"is_active"`
	CreatedAt time.Time `json:"created_at"`
}

// LoginRequest for user login
type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

// RegisterRequest for user registration
type RegisterRequest struct {
	Name     string `json:"name"`
	Email    string `json:"email"`
	Password string `json:"password"`
	Role     string `json:"role"` // siswa by default
}

// AuthResponse after successful login/register
type AuthResponse struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
	Role  string `json:"role"`
	Token string `json:"token"`
}

// Room represents a classroom or lab
type Room struct {
	ID       int    `json:"id"`
	Name     string `json:"name"`
	Type     string `json:"type"` // kelas or lab
	Capacity int    `json:"capacity"`
	IsActive bool   `json:"is_active"`
}

// Booking represents a room booking
type Booking struct {
	ID        int       `json:"id"`
	RoomID    int       `json:"room_id"`
	UserID    int       `json:"user_id"`
	Date      string    `json:"date"` // YYYY-MM-DD format
	StartTime string    `json:"start_time"` // HH:MM format
	EndTime   string    `json:"end_time"`   // HH:MM format
	Purpose   string    `json:"purpose"`
	Status    string    `json:"status"` // pending, approved, rejected
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// BookingSummary for report generation
type BookingSummary struct {
	RoomName  string `json:"room_name"`
	TotalHours float64 `json:"total_hours"`
}

// MonthlyReport for JSON export
type MonthlyReport struct {
	Month    string     `json:"month"`
	Bookings []Booking  `json:"bookings"`
}
