package repository

import (
	"database/sql"
	"fmt"
	"pesan-ruang/models"
)

// RoomRepository handles database operations for rooms
type RoomRepository struct {
	db *sql.DB
}

// NewRoomRepository creates a new room repository
func NewRoomRepository(db *sql.DB) *RoomRepository {
	return &RoomRepository{db: db}
}

// GetAllRooms retrieves all rooms from database
func (r *RoomRepository) GetAllRooms() ([]models.Room, error) {
	query := "SELECT id, name, type, capacity, is_active FROM rooms"
	rows, err := r.db.Query(query)
	if err != nil {
		return nil, fmt.Errorf("failed to query rooms: %w", err)
	}
	defer rows.Close()

	var rooms []models.Room
	for rows.Next() {
		var room models.Room
		err := rows.Scan(&room.ID, &room.Name, &room.Type, &room.Capacity, &room.IsActive)
		if err != nil {
			return nil, fmt.Errorf("failed to scan room: %w", err)
		}
		rooms = append(rooms, room)
	}

	return rooms, nil
}

// GetRoomByID retrieves a room by its ID
func (r *RoomRepository) GetRoomByID(id int) (*models.Room, error) {
	query := "SELECT id, name, type, capacity, is_active FROM rooms WHERE id = ?"
	row := r.db.QueryRow(query, id)

	var room models.Room
	err := row.Scan(&room.ID, &room.Name, &room.Type, &room.Capacity, &room.IsActive)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("room not found")
		}
		return nil, fmt.Errorf("failed to query room: %w", err)
	}

	return &room, nil
}

// CreateRoom creates a new room
func (r *RoomRepository) CreateRoom(room *models.Room) (int, error) {
	query := "INSERT INTO rooms (name, type, capacity, is_active) VALUES (?, ?, ?, ?)"
	result, err := r.db.Exec(query, room.Name, room.Type, room.Capacity, room.IsActive)
	if err != nil {
		return 0, fmt.Errorf("failed to insert room: %w", err)
	}

	id, err := result.LastInsertId()
	if err != nil {
		return 0, fmt.Errorf("failed to get last insert id: %w", err)
	}

	return int(id), nil
}

// UpdateRoom updates room information
func (r *RoomRepository) UpdateRoom(room *models.Room) error {
	query := "UPDATE rooms SET name = ?, type = ?, capacity = ?, is_active = ? WHERE id = ?"
	result, err := r.db.Exec(query, room.Name, room.Type, room.Capacity, room.IsActive, room.ID)
	if err != nil {
		return fmt.Errorf("failed to update room: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to get rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return fmt.Errorf("room not found")
	}

	return nil
}

// DeleteRoom deletes a room only if it has no active bookings
func (r *RoomRepository) DeleteRoom(id int) error {
	// Check if room has active bookings
	query := "SELECT COUNT(*) FROM bookings WHERE room_id = ? AND status IN ('pending', 'approved')"
	var count int
	err := r.db.QueryRow(query, id).Scan(&count)
	if err != nil {
		return fmt.Errorf("failed to check bookings: %w", err)
	}

	if count > 0 {
		return fmt.Errorf("cannot delete room with active bookings")
	}

	deleteQuery := "DELETE FROM rooms WHERE id = ?"
	result, err := r.db.Exec(deleteQuery, id)
	if err != nil {
		return fmt.Errorf("failed to delete room: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to get rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return fmt.Errorf("room not found")
	}

	return nil
}
