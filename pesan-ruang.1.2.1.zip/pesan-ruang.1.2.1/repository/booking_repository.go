package repository

import (
	"database/sql"
	"fmt"
	"pesan-ruang/models"
	"time"
)

// BookingRepository handles database operations for bookings
type BookingRepository struct {
	db *sql.DB
}

// NewBookingRepository creates a new booking repository
func NewBookingRepository(db *sql.DB) *BookingRepository {
	return &BookingRepository{db: db}
}

// GetAllBookings retrieves all bookings
func (r *BookingRepository) GetAllBookings() ([]models.Booking, error) {
	query := `SELECT id, room_id, user_id, date, start_time, end_time, purpose, status, 
	          created_at, updated_at FROM bookings ORDER BY date DESC, start_time DESC`
	rows, err := r.db.Query(query)
	if err != nil {
		return nil, fmt.Errorf("failed to query bookings: %w", err)
	}
	defer rows.Close()

	var bookings []models.Booking
	for rows.Next() {
		var booking models.Booking
		var createdAt, updatedAt sql.NullTime
		var dateVal sql.NullTime
		err := rows.Scan(&booking.ID, &booking.RoomID, &booking.UserID, &dateVal,
			&booking.StartTime, &booking.EndTime, &booking.Purpose, &booking.Status,
			&createdAt, &updatedAt)
		if err != nil {
			return nil, fmt.Errorf("failed to scan booking: %w", err)
		}
		// Convert date to YYYY-MM-DD format
		if dateVal.Valid {
			booking.Date = dateVal.Time.Format("2006-01-02")
		}
		if createdAt.Valid {
			booking.CreatedAt = createdAt.Time
		}
		if updatedAt.Valid {
			booking.UpdatedAt = updatedAt.Time
		}
		bookings = append(bookings, booking)
	}

	return bookings, nil
}

// GetBookingsByUserID retrieves bookings for a specific user
func (r *BookingRepository) GetBookingsByUserID(userID int) ([]models.Booking, error) {
	query := `SELECT id, room_id, user_id, date, start_time, end_time, purpose, status, 
	          created_at, updated_at FROM bookings WHERE user_id = ? ORDER BY date DESC`
	rows, err := r.db.Query(query, userID)
	if err != nil {
		return nil, fmt.Errorf("failed to query bookings: %w", err)
	}
	defer rows.Close()

	var bookings []models.Booking
	for rows.Next() {
		var booking models.Booking
		var createdAt, updatedAt sql.NullTime
		var dateVal sql.NullTime
		err := rows.Scan(&booking.ID, &booking.RoomID, &booking.UserID, &dateVal,
			&booking.StartTime, &booking.EndTime, &booking.Purpose, &booking.Status,
			&createdAt, &updatedAt)
		if err != nil {
			return nil, fmt.Errorf("failed to scan booking: %w", err)
		}
		// Convert date to YYYY-MM-DD format
		if dateVal.Valid {
			booking.Date = dateVal.Time.Format("2006-01-02")
		}
		if createdAt.Valid {
			booking.CreatedAt = createdAt.Time
		}
		if updatedAt.Valid {
			booking.UpdatedAt = updatedAt.Time
		}
		bookings = append(bookings, booking)
	}

	return bookings, nil
}

// GetBookingsByRoomAndDate retrieves all bookings for a room on a specific date
func (r *BookingRepository) GetBookingsByRoomAndDate(roomID int, date string) ([]models.Booking, error) {
	query := `SELECT id, room_id, user_id, date, start_time, end_time, purpose, status, 
	          created_at, updated_at FROM bookings WHERE room_id = ? AND date = ? AND status != 'rejected'`
	rows, err := r.db.Query(query, roomID, date)
	if err != nil {
		return nil, fmt.Errorf("failed to query bookings: %w", err)
	}
	defer rows.Close()

	var bookings []models.Booking
	for rows.Next() {
		var booking models.Booking
		var createdAt, updatedAt sql.NullTime
		var dateVal sql.NullTime
		err := rows.Scan(&booking.ID, &booking.RoomID, &booking.UserID, &dateVal,
			&booking.StartTime, &booking.EndTime, &booking.Purpose, &booking.Status,
			&createdAt, &updatedAt)
		if err != nil {
			return nil, fmt.Errorf("failed to scan booking: %w", err)
		}
		// Convert date to YYYY-MM-DD format
		if dateVal.Valid {
			booking.Date = dateVal.Time.Format("2006-01-02")
		}
		if createdAt.Valid {
			booking.CreatedAt = createdAt.Time
		}
		if updatedAt.Valid {
			booking.UpdatedAt = updatedAt.Time
		}
		bookings = append(bookings, booking)
	}

	return bookings, nil
}

// GetBookingByID retrieves a booking by its ID
func (r *BookingRepository) GetBookingByID(id int) (*models.Booking, error) {
	query := `SELECT id, room_id, user_id, date, start_time, end_time, purpose, status, 
	          created_at, updated_at FROM bookings WHERE id = ?`
	row := r.db.QueryRow(query, id)

	var booking models.Booking
	var createdAt, updatedAt sql.NullTime
	var dateVal sql.NullTime
	err := row.Scan(&booking.ID, &booking.RoomID, &booking.UserID, &dateVal,
		&booking.StartTime, &booking.EndTime, &booking.Purpose, &booking.Status,
		&createdAt, &updatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("booking not found")
		}
		return nil, fmt.Errorf("failed to query booking: %w", err)
	}

	// Convert date to YYYY-MM-DD format
	if dateVal.Valid {
		booking.Date = dateVal.Time.Format("2006-01-02")
	}

	if createdAt.Valid {
		booking.CreatedAt = createdAt.Time
	}
	if updatedAt.Valid {
		booking.UpdatedAt = updatedAt.Time
	}

	return &booking, nil
}

// CreateBooking creates a new booking
func (r *BookingRepository) CreateBooking(booking *models.Booking) (int, error) {
	query := `INSERT INTO bookings (room_id, user_id, date, start_time, end_time, purpose, status) 
	          VALUES (?, ?, ?, ?, ?, ?, ?)`
	result, err := r.db.Exec(query, booking.RoomID, booking.UserID, booking.Date,
		booking.StartTime, booking.EndTime, booking.Purpose, booking.Status)
	if err != nil {
		return 0, fmt.Errorf("failed to insert booking: %w", err)
	}

	id, err := result.LastInsertId()
	if err != nil {
		return 0, fmt.Errorf("failed to get last insert id: %w", err)
	}

	return int(id), nil
}

// UpdateBookingStatus updates the status of a booking
func (r *BookingRepository) UpdateBookingStatus(id int, status string) error {
	query := "UPDATE bookings SET status = ?, updated_at = ? WHERE id = ?"
	result, err := r.db.Exec(query, status, time.Now(), id)
	if err != nil {
		return fmt.Errorf("failed to update booking status: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("failed to get rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return fmt.Errorf("booking not found")
	}

	return nil
}

// GetBookingsByMonth retrieves all approved bookings for a specific month
func (r *BookingRepository) GetBookingsByMonth(year, month int) ([]models.Booking, error) {
	query := `SELECT id, room_id, user_id, date, start_time, end_time, purpose, status, 
	          created_at, updated_at FROM bookings 
	          WHERE YEAR(date) = ? AND MONTH(date) = ? AND status = 'approved'
	          ORDER BY date ASC`
	rows, err := r.db.Query(query, year, month)
	if err != nil {
		return nil, fmt.Errorf("failed to query bookings: %w", err)
	}
	defer rows.Close()

	var bookings []models.Booking
	for rows.Next() {
		var booking models.Booking
		var createdAt, updatedAt sql.NullTime
		err := rows.Scan(&booking.ID, &booking.RoomID, &booking.UserID, &booking.Date,
			&booking.StartTime, &booking.EndTime, &booking.Purpose, &booking.Status,
			&createdAt, &updatedAt)
		if err != nil {
			return nil, fmt.Errorf("failed to scan booking: %w", err)
		}
		if createdAt.Valid {
			booking.CreatedAt = createdAt.Time
		}
		if updatedAt.Valid {
			booking.UpdatedAt = updatedAt.Time
		}
		bookings = append(bookings, booking)
	}

	return bookings, nil
}
