// Admin Dashboard JavaScript
let currentUser = null;

document.addEventListener('DOMContentLoaded', () => {
    currentUser = checkAuth();
    if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/user/';
        return;
    }
    
    document.getElementById('admin-name').textContent = currentUser.name;
    loadDashboard();
});

// Navigation
function showDashboard(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('dashboard-section').style.display = 'block';
    updateActiveNav(0);
    loadDashboard();
}

function showRooms(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('rooms-section').style.display = 'block';
    updateActiveNav(1);
    loadRooms();
}

function showBookings(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('bookings-section').style.display = 'block';
    updateActiveNav(2);
    loadBookings();
}

function showReports(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('reports-section').style.display = 'block';
    updateActiveNav(3);
}

function hideAllSections() {
    document.querySelectorAll('.section-content').forEach(el => {
        el.style.display = 'none';
    });
}

function updateActiveNav(index) {
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    navLinks.forEach((link, i) => {
        if (i < 4) {
            link.classList.toggle('active', i === index);
        }
    });
}

// Dashboard
async function loadDashboard() {
    try {
        const rooms = await apiCall('/rooms') || [];
        const bookings = await apiCall('/bookings') || [];
        
        const totalRooms = Array.isArray(rooms) ? rooms.length : 0;
        const approvedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'approved').length : 0;
        const pendingBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'pending').length : 0;
        const rejectedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'rejected').length : 0;
        
        document.getElementById('total-rooms').textContent = totalRooms;
        document.getElementById('approved-bookings').textContent = approvedBookings;
        document.getElementById('pending-bookings').textContent = pendingBookings;
        document.getElementById('rejected-bookings').textContent = rejectedBookings;
    } catch (error) {
        showAlert('Gagal memuat dashboard: ' + error.message, 'danger');
    }
}

// Rooms Management
async function loadRooms() {
    try {
        const rooms = await apiCall('/rooms') || [];
        const tbody = document.getElementById('rooms-list');
        tbody.innerHTML = '';
        
        if (!Array.isArray(rooms) || rooms.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Tidak ada ruang</td></tr>';
            return;
        }
        
        rooms.forEach((room, index) => {
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${room.name}</td>
                    <td><span class="badge bg-info">${room.type}</span></td>
                    <td>${room.capacity}</td>
                    <td><span class="badge ${room.is_active ? 'bg-success' : 'bg-secondary'}">${room.is_active ? 'Aktif' : 'Tidak Aktif'}</span></td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="editRoom(${room.id})">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteRoom(${room.id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showAlert('Gagal memuat ruang: ' + error.message, 'danger');
    }
}

function openAddRoomModal() {
    document.getElementById('room-name').value = '';
    document.getElementById('room-type').value = 'kelas';
    document.getElementById('room-capacity').value = '';
    document.getElementById('room-active').checked = true;
    
    new bootstrap.Modal(document.getElementById('roomModal')).show();
}

function editRoom(roomId) {
    showAlert('Edit fitur akan ditambahkan', 'info');
}

async function deleteRoom(roomId) {
    if (!confirm('Apakah Anda yakin ingin menghapus ruang ini?')) return;
    
    try {
        await apiCall(`/rooms/${roomId}`, 'DELETE');
        showAlert('Ruang berhasil dihapus', 'success');
        loadRooms();
    } catch (error) {
        showAlert('Gagal menghapus ruang: ' + error.message, 'danger');
    }
}

async function saveRoom() {
    const name = document.getElementById('room-name').value;
    const type = document.getElementById('room-type').value;
    const capacity = document.getElementById('room-capacity').value;
    const isActive = document.getElementById('room-active').checked;
    
    if (!name || !type || !capacity) {
        showAlert('Semua field harus diisi', 'warning');
        return;
    }
    
    try {
        await apiCall('/rooms', 'POST', {
            name,
            type,
            capacity: parseInt(capacity),
            is_active: isActive
        });
        
        showAlert('Ruang berhasil ditambahkan', 'success');
        bootstrap.Modal.getInstance(document.getElementById('roomModal')).hide();
        loadRooms();
    } catch (error) {
        showAlert('Gagal menambahkan ruang: ' + error.message, 'danger');
    }
}

// Bookings Management
async function loadBookings() {
    try {
        const bookings = await apiCall('/bookings') || [];
        const rooms = await apiCall('/rooms') || [];
        
        const tbody = document.getElementById('bookings-list');
        tbody.innerHTML = '';
        
        if (!Array.isArray(bookings) || bookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Tidak ada pemesanan</td></tr>';
            return;
        }
        
        bookings.forEach((booking, index) => {
            const room = rooms.find(r => r.id === booking.room_id);
            const roomName = room ? room.name : 'Unknown';
            const statusBadge = getStatusBadge(booking.status);
            
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${roomName}</td>
                    <td>${booking.date}</td>
                    <td>${booking.start_time} - ${booking.end_time}</td>
                    <td>${booking.purpose}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${booking.status === 'pending' ? `
                            <button class="btn btn-sm btn-success" onclick="approveBooking(${booking.id})">
                                <i class="bi bi-check"></i> Approve
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="rejectBooking(${booking.id})">
                                <i class="bi bi-x"></i> Reject
                            </button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showAlert('Gagal memuat pemesanan: ' + error.message, 'danger');
    }
}

function getStatusBadge(status) {
    const badges = {
        'pending': '<span class="badge bg-warning">Pending</span>',
        'approved': '<span class="badge bg-success">Disetujui</span>',
        'rejected': '<span class="badge bg-danger">Ditolak</span>'
    };
    return badges[status] || status;
}

async function approveBooking(bookingId) {
    try {
        await apiCall(`/bookings/${bookingId}?action=approve`, 'POST');
        showAlert('Pemesanan berhasil disetujui', 'success');
        loadBookings();
    } catch (error) {
        showAlert('Gagal menyetujui pemesanan: ' + error.message, 'danger');
    }
}

async function rejectBooking(bookingId) {
    try {
        await apiCall(`/bookings/${bookingId}?action=reject`, 'POST');
        showAlert('Pemesanan berhasil ditolak', 'success');
        loadBookings();
    } catch (error) {
        showAlert('Gagal menolak pemesanan: ' + error.message, 'danger');
    }
}
