// User Dashboard JavaScript
let currentUser = null;
let currentRoomId = null;

document.addEventListener('DOMContentLoaded', () => {
    currentUser = checkAuth();
    if (!currentUser || currentUser.role === 'admin') {
        window.location.href = '/admin/';
        return;
    }
    
    document.getElementById('user-name').textContent = currentUser.name;
    loadDashboard();
});

// Navigation
function showDashboard(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('dashboard-section').style.display = 'block';
    updateActiveNav(0);
    loadDashboard();
}

function showRooms(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('rooms-section').style.display = 'block';
    updateActiveNav(1);
    loadRoomsGrid();
}

function showMyBookings(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('my-bookings-section').style.display = 'block';
    updateActiveNav(2);
    loadMyBookings();
}

function hideAllSections() {
    document.querySelectorAll('.section-content').forEach(el => {
        el.style.display = 'none';
    });
}

function updateActiveNav(index) {
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    navLinks.forEach((link, i) => {
        if (i < 3) {
            link.classList.toggle('active', i === index);
        }
    });
}

// Dashboard
async function loadDashboard() {
    try {
        const rooms = await apiCall('/rooms') || [];
        const bookings = await apiCall('/bookings') || [];
        
        const totalRooms = Array.isArray(rooms) ? rooms.filter(r => r.is_active).length : 0;
        const myBookings = Array.isArray(bookings) ? bookings.filter(b => b.user_id === currentUser.id) : [];
        const approvedBookings = myBookings.filter(b => b.status === 'approved').length;
        const pendingBookings = myBookings.filter(b => b.status === 'pending').length;
        
        document.getElementById('total-rooms').textContent = totalRooms;
        document.getElementById('my-approved').textContent = approvedBookings;
        document.getElementById('my-pending').textContent = pendingBookings;
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Rooms Grid
async function loadRoomsGrid() {
    try {
        const rooms = await apiCall('/rooms') || [];
        const grid = document.getElementById('rooms-grid');
        grid.innerHTML = '';
        
        if (!Array.isArray(rooms) || rooms.length === 0) {
            grid.innerHTML = '<div class="col-12 text-center text-muted">Tidak ada ruang tersedia</div>';
            return;
        }
        
        rooms.filter(r => r.is_active).forEach(room => {
            grid.innerHTML += `
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card h-100 shadow-sm room-card">
                        <div class="card-body">
                            <h5 class="card-title">${room.name}</h5>
                            <p class="card-text">
                                <strong>Tipe:</strong> <span class="badge bg-info">${room.type}</span><br>
                                <strong>Kapasitas:</strong> ${room.capacity} orang
                            </p>
                            <button class="btn btn-primary w-100" onclick="openBookingModal(${room.id}, '${room.name}')">
                                <i class="bi bi-calendar-plus"></i> Pesan Sekarang
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
    } catch (error) {
        showAlert('Gagal memuat ruang: ' + error.message, 'danger');
    }
}

function openBookingModal(roomId, roomName) {
    currentRoomId = roomId;
    document.getElementById('booking-date').value = '';
    document.getElementById('booking-start-time').value = '';
    document.getElementById('booking-end-time').value = '';
    document.getElementById('booking-purpose').value = '';
    document.getElementById('booking-room-display').textContent = roomName;
    
    new bootstrap.Modal(document.getElementById('bookingModal')).show();
}

async function saveBooking() {
    const date = document.getElementById('booking-date').value;
    const startTime = document.getElementById('booking-start-time').value;
    const endTime = document.getElementById('booking-end-time').value;
    const purpose = document.getElementById('booking-purpose').value;
    
    if (!date || !startTime || !endTime || !purpose) {
        showAlert('Semua field harus diisi', 'warning');
        return;
    }
    
    // Format time to HH:MM
    const start = startTime.length === 5 ? startTime : startTime + ':00';
    const end = endTime.length === 5 ? endTime : endTime + ':00';
    
    try {
        await apiCall('/bookings', 'POST', {
            room_id: currentRoomId,
            user_id: currentUser.id,
            date: date,
            start_time: start,
            end_time: end,
            purpose: purpose,
            status: 'pending'
        });
        
        showAlert('Pemesanan berhasil dibuat', 'success');
        bootstrap.Modal.getInstance(document.getElementById('bookingModal')).hide();
        loadDashboard();
    } catch (error) {
        showAlert('Gagal membuat pemesanan: ' + error.message, 'danger');
    }
}

// My Bookings
async function loadMyBookings() {
    try {
        const bookings = await apiCall('/bookings') || [];
        const rooms = await apiCall('/rooms') || [];
        
        const tbody = document.getElementById('my-bookings-list');
        tbody.innerHTML = '';
        
        const myBookings = Array.isArray(bookings) ? bookings.filter(b => b.user_id === currentUser.id) : [];
        
        if (myBookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">Tidak ada pemesanan</td></tr>';
            return;
        }
        
        myBookings.forEach(booking => {
            const room = rooms.find(r => r.id === booking.room_id);
            const roomName = room ? room.name : 'Unknown';
            const statusBadge = getStatusBadge(booking.status);
            
            tbody.innerHTML += `
                <tr>
                    <td>${roomName}</td>
                    <td>${booking.date}</td>
                    <td>${booking.start_time} - ${booking.end_time}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${booking.status === 'pending' ? `
                            <button class="btn btn-sm btn-danger" onclick="cancelBooking(${booking.id})">
                                <i class="bi bi-x"></i> Batal
                            </button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        showAlert('Gagal memuat pemesanan: ' + error.message, 'danger');
    }
}

function getStatusBadge(status) {
    const badges = {
        'pending': '<span class="badge bg-warning">Pending</span>',
        'approved': '<span class="badge bg-success">Disetujui</span>',
        'rejected': '<span class="badge bg-danger">Ditolak</span>'
    };
    return badges[status] || status;
}

async function cancelBooking(bookingId) {
    if (!confirm('Apakah Anda yakin ingin membatalkan pemesanan ini?')) return;
    
    try {
        await apiCall(`/bookings/${bookingId}?action=reject`, 'POST');
        showAlert('Pemesanan berhasil dibatalkan', 'success');
        loadMyBookings();
    } catch (error) {
        showAlert('Gagal membatalkan pemesanan: ' + error.message, 'danger');
    }
}
