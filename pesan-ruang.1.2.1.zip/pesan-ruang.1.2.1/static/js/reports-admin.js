const API = 'http://localhost:8080';

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    populateYearMonth();
    // Auto-load report setelah populateYearMonth selesai
    setTimeout(() => {
        loadReportData();
    }, 100);
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    console.log('Auth check - token:', !!token, 'user role:', user.role);
    if (!token || user.role !== 'admin') {
        console.warn('Auth failed, redirecting to login');
        window.location.href = '/login.html';
    }
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) location.href = '/login.html';
        throw new Error(await res.text());
    }
    return res.json();
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

function populateYearMonth() {
    const now = new Date();
    const yearSelect = document.getElementById('report-year');
    const monthSelect = document.getElementById('report-month');

    // Populate years (current year and last 2 years)
    for (let i = 0; i < 3; i++) {
        const year = now.getFullYear() - i;
        const opt = document.createElement('option');
        opt.value = year;
        opt.textContent = year;
        yearSelect.appendChild(opt);
    }

    // Populate months
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    monthNames.forEach((name, idx) => {
        const opt = document.createElement('option');
        opt.value = String(idx + 1).padStart(2, '0');
        opt.textContent = name;
        monthSelect.appendChild(opt);
    });

    // Set to current month
    monthSelect.value = String(now.getMonth() + 1).padStart(2, '0');
}

async function loadReportData() {
    try {
        const year = document.getElementById('report-year')?.value;
        const month = document.getElementById('report-month')?.value;
        
        if (!year || !month) {
            console.warn('Year or month not selected');
            return;
        }
        
        console.log(`Loading report for ${year}-${month}`);
        const res = await apiCall(`/report?year=${year}&month=${month}`);
        console.log('Report API response:', res);
        
        if (!res || !res.summary) {
            showAlert('Tidak ada data untuk bulan ini', 'info');
            document.getElementById('report-preview').style.display = 'none';
            return;
        }
        
        displayReport(res, year, month);
    } catch (e) {
        console.error('Error loading report:', e);
        showAlert('Error: ' + e.message, 'danger');
    }
}

function displayReport(data, year, month) {
    console.log('Displaying report:', data);
    const tbody = document.getElementById('report-data');
    const preview = document.getElementById('report-preview');
    
    if (!tbody || !preview) {
        console.error('report-data or report-preview element not found!');
        return;
    }
    
    tbody.innerHTML = '';

    if (!data || !data.summary || data.summary.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Tidak ada data pemesanan untuk bulan ini</td></tr>';
        preview.style.display = 'block';
        return;
    }

    console.log(`Rendering ${data.summary.length} rows`);
    data.summary.forEach((item, i) => {
        const row = `
            <tr>
                <td>${i + 1}</td>
                <td>${item.room_name || 'Unknown'}</td>
                <td>${item.total_bookings}</td>
                <td>${item.total_waktu_pemesanan}</td>
            </tr>
        `;
        tbody.innerHTML += row;
    });

    document.getElementById('report-month-display').textContent = `${year}-${month}`;
    preview.style.display = 'block';
    console.log('Report displayed successfully');
}

function generateReport() {
    loadReportData();
}

function downloadReportCSV() {
    try {
        const year = document.getElementById('report-year').value;
        const month = document.getElementById('report-month').value;
        const rows = document.querySelectorAll('#report-data tr');
        
        if (rows.length === 0) {
            showAlert('Tidak ada data untuk didownload', 'warning');
            return;
        }
        
        let csv = 'No,Nama Ruang,Total Pemesanan,Total Waktu Pemesanan\n';
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 4) {
                // Escape quotes dan commas dalam data
                const roomName = cells[1].textContent.replace(/"/g, '""');
                const totalBookings = cells[2].textContent.trim();
                const totalWaktu = cells[3].textContent.trim();
                csv += `${cells[0].textContent.trim()},"${roomName}",${totalBookings},${totalWaktu}\n`;
            }
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `laporan_${year}${month}.csv`;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
        
        showAlert('✓ Report CSV berhasil didownload!', 'success');
    } catch (e) {
        console.error('Error downloading CSV:', e);
        showAlert('Error: ' + e.message, 'danger');
    }
}

function downloadReportJSON() {
    try {
        const year = document.getElementById('report-year').value;
        const month = document.getElementById('report-month').value;
        const rows = document.querySelectorAll('#report-data tr');
        
        if (rows.length === 0) {
            showAlert('Tidak ada data untuk didownload', 'warning');
            return;
        }
        
        const data = {
            period: `${year}-${month}`,
            generated_at: new Date().toISOString(),
            summary: []
        };
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 4) {
                data.summary.push({
                    no: parseInt(cells[0].textContent.trim()),
                    room_name: cells[1].textContent.trim(),
                    total_bookings: parseInt(cells[2].textContent.trim()),
                    total_hours: parseFloat(cells[3].textContent.replace(' jam', '').trim())
                });
            }
        });

        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `laporan_${year}${month}.json`;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
        
        showAlert('✓ Report JSON berhasil didownload!', 'success');
    } catch (e) {
        console.error('Error downloading JSON:', e);
        showAlert('Error: ' + e.message, 'danger');
    }
}
