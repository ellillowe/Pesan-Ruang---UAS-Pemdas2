const API = 'http://localhost:8080';
let allRooms = [];

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadRooms();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    if (!token || user.role !== 'admin') {
        window.location.href = '/login.html';
    }
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) location.href = '/login.html';
        throw new Error(await res.text());
    }
    return res.json();
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function loadRooms() {
    try {
        const rooms = await apiCall('/rooms');
        allRooms = rooms || [];
        displayRooms(allRooms);
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

function displayRooms(rooms) {
    const tbody = document.getElementById('rooms-list');
    tbody.innerHTML = '';
    
    if (rooms.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted">Tidak ada ruang ditemukan</td></tr>';
        return;
    }
    
    rooms.forEach((r, i) => {
        tbody.innerHTML += `
            <tr>
                <td>${i + 1}</td>
                <td>${r.name}</td>
                <td><span class="badge bg-info">${r.type}</span></td>
                <td>${r.capacity}</td>
                <td><span class="badge ${r.is_active ? 'bg-success' : 'bg-secondary'}">${r.is_active ? 'Aktif' : 'Tidak Aktif'}</span></td>
                <td>
                    <button class="btn btn-sm btn-warning me-2" onclick="editRoom(${r.id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteRoom(${r.id})">Hapus</button>
                </td>
            </tr>
        `;
    });
}

function filterRooms() {
    const searchTerm = document.getElementById('search-room').value.toLowerCase();
    const filtered = allRooms.filter(room => 
        room.name.toLowerCase().includes(searchTerm)
    );
    displayRooms(filtered);
}

function toggleAddRoomForm() {
    const form = document.getElementById('add-room-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

async function saveRoom() {
    try {
        const name = document.getElementById('room-name').value;
        const type = document.getElementById('room-type').value;
        const capacity = parseInt(document.getElementById('room-capacity').value);

        if (!name || !type || !capacity) {
            showAlert('Semua field harus diisi', 'warning');
            return;
        }

        await apiCall('/rooms', 'POST', { name, type, capacity, is_active: true });
        showAlert('Ruang berhasil ditambahkan', 'success');
        toggleAddRoomForm();
        document.getElementById('room-name').value = '';
        document.getElementById('room-type').value = '';
        document.getElementById('room-capacity').value = '';
        document.getElementById('search-room').value = '';
        loadRooms();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function editRoom(roomId) {
    try {
        const rooms = await apiCall('/rooms');
        const room = (rooms || []).find(r => r.id === roomId);
        
        if (!room) {
            showAlert('Ruang tidak ditemukan', 'danger');
            return;
        }

        document.getElementById('edit-room-id').value = room.id;
        document.getElementById('edit-room-name').value = room.name;
        document.getElementById('edit-room-type').value = room.type;
        document.getElementById('edit-room-capacity').value = room.capacity;
        document.getElementById('edit-room-status').value = room.is_active ? 'true' : 'false';

        new bootstrap.Modal(document.getElementById('editRoomModal')).show();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function saveEditRoom() {
    try {
        const id = parseInt(document.getElementById('edit-room-id').value);
        const name = document.getElementById('edit-room-name').value;
        const type = document.getElementById('edit-room-type').value;
        const capacity = parseInt(document.getElementById('edit-room-capacity').value);
        const isActive = document.getElementById('edit-room-status').value === 'true';

        if (!name || !type || !capacity) {
            showAlert('Semua field harus diisi', 'warning');
            return;
        }

        await apiCall(`/rooms/${id}`, 'PUT', { id, name, type, capacity, is_active: isActive });
        showAlert('Ruang berhasil diperbarui', 'success');
        bootstrap.Modal.getInstance(document.getElementById('editRoomModal')).hide();
        loadRooms();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function deleteRoom(id) {
    if (!confirm('Hapus ruang ini?')) return;
    try {
        await apiCall(`/rooms/${id}`, 'DELETE');
        document.getElementById('search-room').value = '';
        showAlert('Ruang berhasil dihapus', 'success');
        loadRooms();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
