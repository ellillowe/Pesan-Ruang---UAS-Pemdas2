// Admin Dashboard JavaScript

const API_BASE = 'http://localhost:8080';
let currentUser = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadDashboard();
    loadRoomsForDropdown();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const userJSON = localStorage.getItem('current_user');
    
    if (!token || !userJSON) {
        window.location.href = '/login.html';
        return;
    }

    currentUser = JSON.parse(userJSON);
    
    // Check if user is admin
    if (currentUser.role !== 'admin') {
        window.location.href = '/user/';
        return;
    }

    document.getElementById('admin-name').textContent = currentUser.name;
}

// ==================== Navigation ====================

function showDashboard(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('dashboard-section').style.display = 'block';
    setActiveNav(0);
    loadDashboard();
}

function showRooms(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('rooms-section').style.display = 'block';
    setActiveNav(1);
    loadRooms();
}

function showBookings(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('bookings-section').style.display = 'block';
    setActiveNav(2);
    loadBookings();
}

function showReports(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('reports-section').style.display = 'block';
    setActiveNav(3);
}

function hideAllSections() {
    document.getElementById('dashboard-section').style.display = 'none';
    document.getElementById('rooms-section').style.display = 'none';
    document.getElementById('bookings-section').style.display = 'none';
    document.getElementById('reports-section').style.display = 'none';
}

function setActiveNav(index) {
    document.querySelectorAll('.navbar-nav .nav-link').forEach((link, i) => {
        link.classList.toggle('active', i === index);
    });
}

// ==================== Dashboard ====================

async function loadDashboard() {
    try {
        const roomsRes = await fetch(`${API_BASE}/rooms`);
        const rooms = (await roomsRes.json()) || [];
        
        const bookingsRes = await fetch(`${API_BASE}/bookings`);
        const bookings = (await bookingsRes.json()) || [];

        const totalRooms = Array.isArray(rooms) ? rooms.length : 0;
        const approvedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'approved').length : 0;
        const pendingBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'pending').length : 0;
        const rejectedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'rejected').length : 0;

        document.getElementById('total-rooms').textContent = totalRooms;
        document.getElementById('approved-bookings').textContent = approvedBookings;
        document.getElementById('pending-bookings').textContent = pendingBookings;
        document.getElementById('rejected-bookings').textContent = rejectedBookings;
    } catch (error) {
        console.error('Error loading dashboard:', error);
        showAlert('Gagal memuat dashboard', 'danger');
    }
}

// ==================== Rooms Management ====================

async function loadRooms() {
    try {
        const response = await fetch(`${API_BASE}/rooms`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const rooms = await response.json() || [];

        const tbody = document.getElementById('rooms-list');
        tbody.innerHTML = '';

        if (!Array.isArray(rooms) || rooms.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Tidak ada ruang</td></tr>';
            return;
        }

        rooms.forEach((room, index) => {
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${room.name}</td>
                    <td><span class="badge bg-info">${room.type}</span></td>
                    <td>${room.capacity}</td>
                    <td><span class="badge ${room.is_active ? 'bg-success' : 'bg-secondary'}">${room.is_active ? 'Aktif' : 'Tidak Aktif'}</span></td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick="editRoom(${room.id})">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteRoom(${room.id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        console.error('Error loading rooms:', error);
        showAlert('Gagal memuat ruang', 'danger');
    }
}

async function loadRoomsForDropdown() {
    try {
        const response = await fetch(`${API_BASE}/rooms`);
        const rooms = await response.json() || [];
        // Store for later use
        window.allRooms = rooms;
    } catch (error) {
        console.error('Error loading rooms:', error);
    }
}

function openAddRoomModal() {
    document.getElementById('addRoomForm').reset();
    new bootstrap.Modal(document.getElementById('addRoomModal')).show();
}

async function saveRoom() {
    const name = document.getElementById('room-name').value;
    const type = document.getElementById('room-type').value;
    const capacity = parseInt(document.getElementById('room-capacity').value);

    if (!name || !type || !capacity) {
        showAlert('Semua field harus diisi', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/rooms`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, type, capacity, is_active: true })
        });

        if (response.ok) {
            showAlert('Ruang berhasil ditambahkan', 'success');
            bootstrap.Modal.getInstance(document.getElementById('addRoomModal')).hide();
            loadRooms();
            loadRoomsForDropdown();
        } else {
            const error = await response.text();
            showAlert(`Gagal menambahkan ruang: ${error}`, 'danger');
        }
    } catch (error) {
        console.error('Error saving room:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

function editRoom(id) {
    showAlert('Fitur edit sedang dikembangkan', 'info');
}

async function deleteRoom(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus ruang ini?')) return;

    try {
        const response = await fetch(`${API_BASE}/rooms/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showAlert('Ruang berhasil dihapus', 'success');
            loadRooms();
            loadRoomsForDropdown();
        } else {
            showAlert('Gagal menghapus ruang', 'danger');
        }
    } catch (error) {
        console.error('Error deleting room:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== Bookings Management ====================

async function loadBookings() {
    try {
        const response = await fetch(`${API_BASE}/bookings`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const bookings = await response.json() || [];

        const tbody = document.getElementById('bookings-list');
        tbody.innerHTML = '';

        if (!Array.isArray(bookings) || bookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">Tidak ada pemesanan</td></tr>';
            return;
        }

        bookings.forEach((booking, index) => {
            const statusBadge = booking.status === 'approved' ? 'success' : booking.status === 'pending' ? 'warning' : 'danger';
            const statusText = booking.status === 'approved' ? 'Disetujui' : booking.status === 'pending' ? 'Pending' : 'Ditolak';
            
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${booking.room_id}</td>
                    <td>${booking.user_id}</td>
                    <td>${booking.date}</td>
                    <td>${booking.start_time} - ${booking.end_time}</td>
                    <td><span class="badge bg-${statusBadge}">${statusText}</span></td>
                    <td>
                        ${booking.status === 'pending' ? `
                            <button class="btn btn-sm btn-success" onclick="approveBooking(${booking.id})">
                                <i class="bi bi-check"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="rejectBooking(${booking.id})">
                                <i class="bi bi-x"></i>
                            </button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        console.error('Error loading bookings:', error);
        showAlert('Gagal memuat pemesanan', 'danger');
    }
}

async function approveBooking(id) {
    try {
        const response = await fetch(`${API_BASE}/bookings/${id}?action=approve`, { method: 'POST' });
        if (response.ok) {
            showAlert('Pemesanan disetujui', 'success');
            loadBookings();
        } else {
            showAlert('Gagal menyetujui pemesanan', 'danger');
        }
    } catch (error) {
        console.error('Error approving booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

async function rejectBooking(id) {
    try {
        const response = await fetch(`${API_BASE}/bookings/${id}?action=reject`, { method: 'POST' });
        if (response.ok) {
            showAlert('Pemesanan ditolak', 'success');
            loadBookings();
        } else {
            showAlert('Gagal menolak pemesanan', 'danger');
        }
    } catch (error) {
        console.error('Error rejecting booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== Reports ====================

async function exportReport() {
    const month = document.getElementById('report-month').value;
    if (!month) {
        showAlert('Pilih bulan terlebih dahulu', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/report?month=${month}`);
        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `report-${month}.pdf`;
            a.click();
            showAlert('Laporan berhasil di-download', 'success');
        } else {
            showAlert('Gagal mengunduh laporan', 'danger');
        }
    } catch (error) {
        console.error('Error exporting report:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== Utilities ====================

function logout() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('current_user');
        window.location.href = '/login.html';
    }
}

function showAlert(message, type = 'info') {
    const alertId = 'alert-' + Date.now();
    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show position-fixed" 
             style="top: 80px; right: 20px; z-index: 9999; min-width: 300px;" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    const container = document.getElementById('alert-container');
    container.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const element = document.getElementById(alertId);
        if (element) {
            element.remove();
        }
    }, 5000);
}
