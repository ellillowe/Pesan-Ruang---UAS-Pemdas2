// User Dashboard JavaScript

const API_BASE = 'http://localhost:8080';
let currentUser = null;
let currentRoomId = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadDashboard();
    loadRoomsForGrid();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const userJSON = localStorage.getItem('current_user');
    
    if (!token || !userJSON) {
        window.location.href = '/login.html';
        return;
    }

    currentUser = JSON.parse(userJSON);
    
    // Check if user is NOT admin (allow siswa to access)
    if (currentUser.role === 'admin') {
        window.location.href = '/admin/';
        return;
    }

    document.getElementById('user-name').textContent = currentUser.name;
}

// ==================== Navigation ====================

function showDashboard(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('dashboard-section').style.display = 'block';
    setActiveNav(0);
    loadDashboard();
}

function showRooms(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('rooms-section').style.display = 'block';
    setActiveNav(1);
    loadRoomsForGrid();
}

function showMyBookings(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('my-bookings-section').style.display = 'block';
    setActiveNav(2);
    loadMyBookings();
}

function hideAllSections() {
    document.getElementById('dashboard-section').style.display = 'none';
    document.getElementById('rooms-section').style.display = 'none';
    document.getElementById('my-bookings-section').style.display = 'none';
}

function setActiveNav(index) {
    document.querySelectorAll('.navbar-nav .nav-link').forEach((link, i) => {
        if (i === 0 || i === 1 || i === 2) {
            link.classList.toggle('active', i === index);
        }
    });
}

// ==================== Dashboard ====================

async function loadDashboard() {
    try {
        const roomsRes = await fetch(`${API_BASE}/rooms`);
        const rooms = (await roomsRes.json()) || [];
        
        const bookingsRes = await fetch(`${API_BASE}/bookings?user_id=${currentUser.id}`);
        const bookings = (await bookingsRes.json()) || [];

        const totalRooms = Array.isArray(rooms) ? rooms.length : 0;
        const approvedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'approved').length : 0;
        const pendingBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'pending').length : 0;

        document.getElementById('total-rooms').textContent = totalRooms;
        document.getElementById('my-approved').textContent = approvedBookings;
        document.getElementById('my-pending').textContent = pendingBookings;
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// ==================== Rooms Grid ====================

async function loadRoomsForGrid() {
    try {
        const response = await fetch(`${API_BASE}/rooms`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const rooms = await response.json() || [];

        const grid = document.getElementById('rooms-grid');
        grid.innerHTML = '';

        if (!Array.isArray(rooms) || rooms.length === 0) {
            grid.innerHTML = '<div class="col-12 text-center text-muted">Tidak ada ruang tersedia</div>';
            return;
        }

        rooms.forEach((room) => {
            if (room.is_active) {
                grid.innerHTML += `
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">${room.name}</h5>
                                <p class="card-text">
                                    <strong>Tipe:</strong> <span class="badge bg-info">${room.type}</span><br>
                                    <strong>Kapasitas:</strong> ${room.capacity} orang
                                </p>
                                <button class="btn btn-primary w-100" onclick="openBookingModal(${room.id}, '${room.name}')">
                                    <i class="bi bi-calendar-plus"></i> Pesan Sekarang
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }
        });
    } catch (error) {
        console.error('Error loading rooms:', error);
        showAlert('Gagal memuat ruang', 'danger');
    }
}

function openBookingModal(roomId, roomName) {
    currentRoomId = roomId;
    document.getElementById('booking-room-id').value = roomId;
    document.getElementById('booking-room-name').value = roomName;
    document.getElementById('booking-user-name').value = currentUser.name;
    document.getElementById('bookingForm').reset();
    document.getElementById('booking-room-name').value = roomName;
    document.getElementById('booking-user-name').value = currentUser.name;
    
    new bootstrap.Modal(document.getElementById('bookRoomModal')).show();
}

async function saveBooking() {
    const roomId = parseInt(document.getElementById('booking-room-id').value);
    const date = document.getElementById('booking-date').value;
    const startTime = document.getElementById('booking-start-time').value;
    const endTime = document.getElementById('booking-end-time').value;
    const purpose = document.getElementById('booking-purpose').value;

    if (!roomId || !date || !startTime || !endTime || !purpose) {
        showAlert('Semua field harus diisi', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/bookings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                room_id: roomId,
                user_id: currentUser.id,
                date: date,
                start_time: startTime + ':00',
                end_time: endTime + ':00',
                purpose: purpose,
                status: 'pending'
            })
        });

        if (response.ok) {
            showAlert('Pemesanan berhasil dibuat! Menunggu persetujuan admin.', 'success');
            bootstrap.Modal.getInstance(document.getElementById('bookRoomModal')).hide();
            loadMyBookings();
            loadDashboard();
        } else {
            const error = await response.text();
            showAlert(`Gagal membuat pemesanan: ${error}`, 'danger');
        }
    } catch (error) {
        console.error('Error saving booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== My Bookings ====================

async function loadMyBookings() {
    try {
        const response = await fetch(`${API_BASE}/bookings`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const allBookings = await response.json() || [];

        // Filter bookings untuk user yang login
        const myBookings = Array.isArray(allBookings) 
            ? allBookings.filter(b => b.user_id === currentUser.id)
            : [];

        const tbody = document.getElementById('my-bookings-list');
        tbody.innerHTML = '';

        if (myBookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">Belum ada pemesanan</td></tr>';
            return;
        }

        myBookings.forEach((booking) => {
            const statusBadge = booking.status === 'approved' ? 'success' : booking.status === 'pending' ? 'warning' : 'danger';
            const statusText = booking.status === 'approved' ? 'Disetujui' : booking.status === 'pending' ? 'Pending' : 'Ditolak';
            
            tbody.innerHTML += `
                <tr>
                    <td>Ruang ${booking.room_id}</td>
                    <td>${booking.date}</td>
                    <td>${booking.start_time} - ${booking.end_time}</td>
                    <td><span class="badge bg-${statusBadge}">${statusText}</span></td>
                    <td>
                        ${booking.status === 'pending' ? `
                            <button class="btn btn-sm btn-danger" onclick="cancelBooking(${booking.id})">
                                <i class="bi bi-x"></i> Batalkan
                            </button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        console.error('Error loading bookings:', error);
        showAlert('Gagal memuat pemesanan', 'danger');
    }
}

async function cancelBooking(id) {
    if (!confirm('Apakah Anda yakin ingin membatalkan pemesanan ini?')) return;

    try {
        const response = await fetch(`${API_BASE}/bookings/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showAlert('Pemesanan dibatalkan', 'success');
            loadMyBookings();
            loadDashboard();
        } else {
            showAlert('Gagal membatalkan pemesanan', 'danger');
        }
    } catch (error) {
        console.error('Error canceling booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== Utilities ====================

function logout() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('current_user');
        window.location.href = '/login.html';
    }
}

function showAlert(message, type = 'info') {
    const alertId = 'alert-' + Date.now();
    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show position-fixed" 
             style="top: 80px; right: 20px; z-index: 9999; min-width: 300px;" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    const container = document.getElementById('alert-container');
    container.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const element = document.getElementById(alertId);
        if (element) {
            element.remove();
        }
    }, 5000);
}
