const API = 'http://localhost:8080';

// Check auth
let currentUser = null;
document.addEventListener('DOMContentLoaded', () => {
    currentUser = checkAuth();
    if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '/login.html';
        return;
    }
    document.getElementById('user-name').textContent = currentUser.name;
    loadDashboard();
    loadRooms();
    loadBookings();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = localStorage.getItem('current_user');
    if (!token || !user) window.location.href = '/login.html';
    return JSON.parse(user);
}

function logout() {
    localStorage.clear();
    window.location.href = '/login.html';
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) {
            logout();
        }
        throw new Error(await res.text());
    }
    return res.json();
}

// Dashboard
async function loadDashboard() {
    try {
        const rooms = await apiCall('/rooms');
        const bookings = await apiCall('/bookings');
        
        document.getElementById('total-rooms').textContent = (rooms || []).length;
        document.getElementById('approved-bookings').textContent = (bookings || []).filter(b => b.status === 'approved').length;
        document.getElementById('pending-bookings').textContent = (bookings || []).filter(b => b.status === 'pending').length;
        document.getElementById('rejected-bookings').textContent = (bookings || []).filter(b => b.status === 'rejected').length;
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

// Rooms
async function loadRooms() {
    try {
        const rooms = await apiCall('/rooms');
        const tbody = document.getElementById('rooms-list');
        tbody.innerHTML = '';
        (rooms || []).forEach((r, i) => {
            tbody.innerHTML += `
                <tr>
                    <td>${i + 1}</td>
                    <td>${r.name}</td>
                    <td><span class="badge bg-info">${r.type}</span></td>
                    <td>${r.capacity}</td>
                    <td><span class="badge ${r.is_active ? 'bg-success' : 'bg-secondary'}">${r.is_active ? 'Aktif' : 'Tidak Aktif'}</span></td>
                    <td>
                        <button class="btn btn-sm btn-warning me-2" onclick="editRoom(${r.id})">Edit</button>
                        <button class="btn btn-sm btn-danger" onclick="deleteRoom(${r.id})">Hapus</button>
                    </td>
                </tr>
            `;
        });
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

function toggleAddRoomForm() {
    const form = document.getElementById('add-room-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

async function saveRoom() {
    try {
        const name = document.getElementById('room-name').value;
        const type = document.getElementById('room-type').value;
        const capacity = parseInt(document.getElementById('room-capacity').value);

        if (!name || !type || !capacity) {
            showAlert('Semua field harus diisi', 'warning');
            return;
        }

        await apiCall('/rooms', 'POST', { name, type, capacity, is_active: true });
        showAlert('Ruang berhasil ditambahkan', 'success');
        toggleAddRoomForm();
        loadRooms();
        loadDashboard();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function deleteRoom(id) {
    if (!confirm('Hapus ruang ini?')) return;
    try {
        await apiCall(`/rooms/${id}`, 'DELETE');
        showAlert('Ruang berhasil dihapus', 'success');
        loadRooms();
        loadDashboard();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

// Bookings
async function loadBookings() {
    try {
        const bookings = await apiCall('/bookings');
        const rooms = await apiCall('/rooms');
        const tbody = document.getElementById('bookings-list');
        tbody.innerHTML = '';
        (bookings || []).forEach((b, i) => {
            const room = (rooms || []).find(r => r.id === b.room_id);
            const statusBadge = {
                'pending': '<span class="badge bg-warning">Pending</span>',
                'approved': '<span class="badge bg-success">Disetujui</span>',
                'rejected': '<span class="badge bg-danger">Ditolak</span>'
            }[b.status] || b.status;
            tbody.innerHTML += `
                <tr>
                    <td>${i + 1}</td>
                    <td>${room?.name || 'Unknown'}</td>
                    <td>${b.date}</td>
                    <td>${b.start_time} - ${b.end_time}</td>
                    <td>${b.purpose}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${b.status === 'pending' ? `
                            <button class="btn btn-sm btn-success" onclick="approveBooking(${b.id})">Approve</button>
                            <button class="btn btn-sm btn-danger" onclick="rejectBooking(${b.id})">Reject</button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function approveBooking(id) {
    try {
        await apiCall(`/bookings/${id}?action=approve`, 'POST');
        showAlert('Pemesanan disetujui', 'success');
        loadBookings();
        loadDashboard();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function rejectBooking(id) {
    try {
        await apiCall(`/bookings/${id}?action=reject`, 'POST');
        showAlert('Pemesanan ditolak', 'success');
        loadBookings();
        loadDashboard();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

// Edit Room
async function editRoom(roomId) {
    try {
        const rooms = await apiCall('/rooms');
        const room = (rooms || []).find(r => r.id === roomId);
        
        if (!room) {
            showAlert('Ruang tidak ditemukan', 'danger');
            return;
        }

        document.getElementById('edit-room-id').value = room.id;
        document.getElementById('edit-room-name').value = room.name;
        document.getElementById('edit-room-type').value = room.type;
        document.getElementById('edit-room-capacity').value = room.capacity;
        document.getElementById('edit-room-status').value = room.is_active ? 'true' : 'false';

        new bootstrap.Modal(document.getElementById('editRoomModal')).show();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function saveEditRoom() {
    try {
        const id = parseInt(document.getElementById('edit-room-id').value);
        const name = document.getElementById('edit-room-name').value;
        const type = document.getElementById('edit-room-type').value;
        const capacity = parseInt(document.getElementById('edit-room-capacity').value);
        const isActive = document.getElementById('edit-room-status').value === 'true';

        if (!name || !type || !capacity) {
            showAlert('Semua field harus diisi', 'warning');
            return;
        }

        await apiCall(`/rooms/${id}`, 'PUT', {
            id,
            name,
            type,
            capacity,
            is_active: isActive
        });

        showAlert('Ruang berhasil diperbarui', 'success');
        bootstrap.Modal.getInstance(document.getElementById('editRoomModal')).hide();
        loadRooms();
        loadDashboard();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
