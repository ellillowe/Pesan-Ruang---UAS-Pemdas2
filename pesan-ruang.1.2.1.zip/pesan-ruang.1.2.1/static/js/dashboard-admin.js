const API = 'http://localhost:8080';

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadDashboard();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    if (!token || user.role !== 'admin') {
        window.location.href = '/login.html';
        return false;
    }
    return true;
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) location.href = '/login.html';
        throw new Error(await res.text());
    }
    return res.json();
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function loadDashboard() {
    try {
        const rooms = await apiCall('/rooms');
        const bookings = await apiCall('/bookings');
        
        document.getElementById('total-rooms').textContent = (rooms || []).length;
        document.getElementById('approved-bookings').textContent = (bookings || []).filter(b => b.status === 'approved').length;
        document.getElementById('pending-bookings').textContent = (bookings || []).filter(b => b.status === 'pending').length;
        document.getElementById('rejected-bookings').textContent = (bookings || []).filter(b => b.status === 'rejected').length;

        // Load recent bookings
        const tbody = document.getElementById('recent-bookings');
        tbody.innerHTML = '';
        const recentBookings = (bookings || []).slice(0, 5);
        const roomsMap = {};
        (rooms || []).forEach(r => roomsMap[r.id] = r.name);

        recentBookings.forEach((b, i) => {
            const statusBadge = {
                'pending': '<span class="badge bg-warning">Pending</span>',
                'approved': '<span class="badge bg-success">Disetujui</span>',
                'rejected': '<span class="badge bg-danger">Ditolak</span>'
            }[b.status] || b.status;
            
            tbody.innerHTML += `
                <tr>
                    <td>${roomsMap[b.room_id] || 'Unknown'}</td>
                    <td>${b.date}</td>
                    <td>${b.start_time} - ${b.end_time}</td>
                    <td>${b.user_id}</td>
                    <td>${statusBadge}</td>
                </tr>
            `;
        });
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
