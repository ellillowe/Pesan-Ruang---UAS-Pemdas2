const API = 'http://localhost:8080';

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    loadDashboard();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    if (!token || user.role === 'admin') {
        window.location.href = '/login.html';
    }
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) location.href = '/login.html';
        throw new Error(await res.text());
    }
    return res.json();
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function loadDashboard() {
    try {
        const user = JSON.parse(localStorage.getItem('current_user') || '{}');
        const rooms = await apiCall('/rooms');
        const bookings = await apiCall('/bookings');
        const myBookings = (bookings || []).filter(b => b.user_id === user.id);

        document.getElementById('total-rooms').textContent = (rooms || []).filter(r => r.is_active).length;
        document.getElementById('approved-bookings').textContent = myBookings.filter(b => b.status === 'approved').length;
        document.getElementById('pending-bookings').textContent = myBookings.filter(b => b.status === 'pending').length;
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
