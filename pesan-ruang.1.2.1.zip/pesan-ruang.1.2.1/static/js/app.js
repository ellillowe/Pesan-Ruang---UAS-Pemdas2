// Sistem Manajemen Pemesanan Ruang - Frontend JavaScript

const API_BASE = 'http://localhost:8080';
let currentUser = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkServerConnection();
    loadSessionUser();
    setCurrentMonth();
});

// Check if user is logged in
function loadSessionUser() {
    const token = localStorage.getItem('auth_token');
    const userJSON = localStorage.getItem('current_user');
    
    if (token && userJSON) {
        currentUser = JSON.parse(userJSON);
        showMainContent();
        loadDashboard();
        loadRoomsForDropdown();
    } else {
        showLoginModal();
        // Hide main content and nav items
        document.getElementById('main-content').style.display = 'none';
        document.getElementById('dashboard-nav').style.display = 'none';
        document.getElementById('rooms-nav').style.display = 'none';
        document.getElementById('bookings-nav').style.display = 'none';
        document.getElementById('reports-nav').style.display = 'none';
        document.getElementById('user-info').style.display = 'none';
        document.getElementById('logout-btn').style.display = 'none';
    }
}

function showMainContent() {
    document.getElementById('main-content').style.display = 'block';
    document.getElementById('dashboard-nav').style.display = 'block';
    document.getElementById('rooms-nav').style.display = 'block';
    document.getElementById('bookings-nav').style.display = 'block';
    document.getElementById('reports-nav').style.display = 'block';
    document.getElementById('user-info').style.display = 'block';
    document.getElementById('logout-btn').style.display = 'block';
    document.getElementById('login-btn').style.display = 'none';
    document.getElementById('user-name').textContent = currentUser.name;
}

function showLoginModal() {
    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'), {
        backdrop: 'static',
        keyboard: false
    });
    loginModal.show();
}

// Check server connection
async function checkServerConnection() {
    try {
        const response = await fetch(`${API_BASE}/api/health`);
        if (!response.ok) {
            console.warn('Server returned status:', response.status);
        }
    } catch (error) {
        console.error('Cannot connect to server:', error);
        showAlert(`⚠️ Tidak bisa terhubung ke server di ${API_BASE}`, 'danger');
    }
}

// ==================== Authentication ====================

function switchToRegister() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
    document.getElementById('modal-title').textContent = 'Daftar Akun';
    document.getElementById('login-submit-btn').style.display = 'none';
    document.getElementById('register-submit-btn').style.display = 'block';
}

function switchToLogin() {
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('modal-title').textContent = 'Login';
    document.getElementById('register-submit-btn').style.display = 'none';
    document.getElementById('login-submit-btn').style.display = 'block';
}

async function handleLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    if (!email || !password) {
        showAlert('Email dan Password harus diisi', 'danger');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Login gagal: ${errorText}`);
        }

        const data = await response.json();
        
        // Store user data and token
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('current_user', JSON.stringify({
            id: data.id,
            name: data.name,
            email: data.email,
            role: data.role
        }));

        currentUser = data;
        
        // Close modal and show main content
        const modal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
        modal.hide();

        showMainContent();
        loadDashboard();
        loadRoomsForDropdown();
        showAlert(`Selamat datang, ${data.name}!`, 'success');

    } catch (error) {
        console.error('Login error:', error);
        showAlert(`${error.message}`, 'danger');
    }
}

async function handleRegister() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const role = document.getElementById('register-role').value;

    if (!name || !email || !password) {
        showAlert('Semua field harus diisi', 'danger');
        return;
    }

    if (password.length < 6) {
        showAlert('Password minimal 6 karakter', 'danger');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, password, role })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Pendaftaran gagal: ${errorText}`);
        }

        const data = await response.json();
        
        // Store user data and token
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('current_user', JSON.stringify({
            id: data.id,
            name: data.name,
            email: data.email,
            role: data.role
        }));

        currentUser = data;
        
        // Close modal and show main content
        const modal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
        modal.hide();

        showMainContent();
        loadDashboard();
        loadRoomsForDropdown();
        showAlert(`Akun berhasil dibuat! Selamat datang, ${data.name}!`, 'success');

    } catch (error) {
        console.error('Register error:', error);
        showAlert(`${error.message}`, 'danger');
    }
}

function logout() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('current_user');
        currentUser = null;
        
        // Reset form
        document.getElementById('loginForm').style.display = 'block';
        document.getElementById('registerForm').style.display = 'none';
        document.getElementById('modal-title').textContent = 'Login';
        document.getElementById('login-email').value = '';
        document.getElementById('login-password').value = '';
        
        showLoginModal();
        showAlert('Logout berhasil', 'info');
    }
}

// ==================== Navigation ====================

function showDashboard(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('dashboard-section').style.display = 'block';
    setActiveNav(0);
    loadDashboard();
}

function showRooms(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('rooms-section').style.display = 'block';
    setActiveNav(1);
    loadRooms();
}

function showBookings(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('bookings-section').style.display = 'block';
    setActiveNav(2);
    loadBookings();
}

function showReports(e) {
    e.preventDefault();
    hideAllSections();
    document.getElementById('reports-section').style.display = 'block';
    setActiveNav(3);
}

function hideAllSections() {
    document.getElementById('dashboard-section').style.display = 'none';
    document.getElementById('rooms-section').style.display = 'none';
    document.getElementById('bookings-section').style.display = 'none';
    document.getElementById('reports-section').style.display = 'none';
}

function setActiveNav(index) {
    document.querySelectorAll('.navbar-nav .nav-link').forEach((link, i) => {
        link.classList.toggle('active', i === index);
    });
}

// ==================== Dashboard ====================

async function loadDashboard() {
    try {
        const roomsRes = await fetch(`${API_BASE}/rooms`);
        if (!roomsRes.ok) throw new Error(`HTTP ${roomsRes.status}`);
        const rooms = await roomsRes.json() || [];
        
        const bookingsRes = await fetch(`${API_BASE}/bookings`);
        if (!bookingsRes.ok) throw new Error(`HTTP ${bookingsRes.status}`);
        const bookings = await bookingsRes.json() || [];

        const totalRooms = Array.isArray(rooms) ? rooms.length : 0;
        const approvedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'approved').length : 0;
        const pendingBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'pending').length : 0;
        const rejectedBookings = Array.isArray(bookings) ? bookings.filter(b => b.status === 'rejected').length : 0;

        document.getElementById('total-rooms').textContent = totalRooms;
        document.getElementById('approved-bookings').textContent = approvedBookings;
        document.getElementById('pending-bookings').textContent = pendingBookings;
        document.getElementById('rejected-bookings').textContent = rejectedBookings;
    } catch (error) {
        console.error('Error loading dashboard:', error);
        console.error('API_BASE:', API_BASE);
        showAlert(`Gagal memuat dashboard: ${error.message}`, 'danger');
    }
}

// ==================== Rooms Management ====================

async function loadRooms() {
    try {
        const response = await fetch(`${API_BASE}/rooms`);
        if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        const rooms = await response.json() || [];
        const tbody = document.getElementById('rooms-table');

        if (!rooms || rooms.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Tidak ada ruang</td></tr>';
            return;
        }

        tbody.innerHTML = rooms.map(room => `
            <tr>
                <td>${room.id}</td>
                <td><strong>${room.name}</strong></td>
                <td>${room.type === 'kelas' ? '📚 Kelas' : '🔬 Lab'}</td>
                <td>${room.capacity} orang</td>
                <td>
                    <span class="badge ${room.is_active ? 'badge-active' : 'badge-inactive'}">
                        ${room.is_active ? 'Aktif' : 'Tidak Aktif'}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick="editRoom(${room.id})">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteRoom(${room.id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading rooms:', error);
        console.error('URL:', `${API_BASE}/rooms`);
        showAlert(`Gagal memuat data ruang: ${error.message}`, 'danger');
    }
}

async function loadRoomsForDropdown() {
    try {
        const response = await fetch(`${API_BASE}/rooms`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const rooms = await response.json() || [];
        const select = document.getElementById('booking-room-id');

        if (rooms && rooms.length > 0) {
            select.innerHTML = '<option value="">Pilih Ruang</option>' + 
                rooms.map(room => `<option value="${room.id}">${room.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading rooms for dropdown:', error);
    }
}

function openAddRoomModal() {
    document.getElementById('addRoomForm').reset();
    new bootstrap.Modal(document.getElementById('addRoomModal')).show();
}

async function saveRoom() {
    const name = document.getElementById('room-name').value;
    const type = document.getElementById('room-type').value;
    const capacity = parseInt(document.getElementById('room-capacity').value);

    if (!name || !type || !capacity) {
        showAlert('Semua field harus diisi', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/rooms`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, type, capacity })
        });

        if (response.ok) {
            showAlert('Ruang berhasil ditambahkan', 'success');
            bootstrap.Modal.getInstance(document.getElementById('addRoomModal')).hide();
            loadRooms();
            loadRoomsForDropdown();
        } else {
            showAlert('Gagal menambahkan ruang', 'danger');
        }
    } catch (error) {
        console.error('Error saving room:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

function editRoom(id) {
    showAlert('Fitur edit sedang dalam pengembangan', 'info');
}

async function deleteRoom(id) {
    if (!confirm('Yakin ingin menghapus ruang ini?')) return;

    try {
        const response = await fetch(`${API_BASE}/rooms/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showAlert('Ruang berhasil dihapus', 'success');
            loadRooms();
            loadRoomsForDropdown();
        } else {
            showAlert('Gagal menghapus ruang', 'danger');
        }
    } catch (error) {
        console.error('Error deleting room:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== Bookings Management ====================

async function loadBookings() {
    try {
        const response = await fetch(`${API_BASE}/bookings`);
        if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        const bookings = await response.json() || [];
        const tbody = document.getElementById('bookings-table');

        if (!bookings || bookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">Tidak ada pemesanan</td></tr>';
            return;
        }

        // Load rooms data for room names
        const roomsRes = await fetch(`${API_BASE}/rooms`);
        if (!roomsRes.ok) throw new Error(`Failed to load rooms: HTTP ${roomsRes.status}`);
        const rooms = await roomsRes.json() || [];
        const roomMap = Object.fromEntries(rooms.map(r => [r.id, r.name]));

        tbody.innerHTML = bookings.map(booking => `
            <tr>
                <td>${booking.id}</td>
                <td>${roomMap[booking.room_id] || 'Unknown'}</td>
                <td>User ${booking.user_id}</td>
                <td>${new Date(booking.date).toLocaleDateString('id-ID')}</td>
                <td>${booking.start_time} - ${booking.end_time}</td>
                <td>${booking.purpose}</td>
                <td>
                    <span class="badge badge-${booking.status}">
                        ${formatStatus(booking.status)}
                    </span>
                </td>
                <td>
                    ${booking.status === 'pending' ? `
                        <button class="btn btn-sm btn-success" onclick="approveBooking(${booking.id})">
                            <i class="bi bi-check"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="rejectBooking(${booking.id})">
                            <i class="bi bi-x"></i>
                        </button>
                    ` : `<small class="text-muted">-</small>`}
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading bookings:', error);
        console.error('URL:', `${API_BASE}/bookings`);
        showAlert(`Gagal memuat data pemesanan: ${error.message}`, 'danger');
    }
}

function openAddBookingModal() {
    if (!currentUser) {
        showAlert('Anda harus login terlebih dahulu', 'danger');
        return;
    }
    
    document.getElementById('addBookingForm').reset();
    // Auto-fill user info
    document.getElementById('booking-user-id').value = currentUser.id;
    document.getElementById('booking-user-name').value = currentUser.name;
    new bootstrap.Modal(document.getElementById('addBookingModal')).show();
}

async function saveBooking() {
    const roomId = parseInt(document.getElementById('booking-room-id').value);
    const date = document.getElementById('booking-date').value;
    const startTime = document.getElementById('booking-start-time').value;
    const endTime = document.getElementById('booking-end-time').value;
    const purpose = document.getElementById('booking-purpose').value;

    if (!roomId || !date || !startTime || !endTime || !purpose) {
        showAlert('Semua field harus diisi', 'warning');
        return;
    }

    if (!currentUser) {
        showAlert('Anda harus login terlebih dahulu', 'danger');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/bookings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                room_id: roomId,
                user_id: currentUser.id,
                date: date,
                start_time: startTime + ':00',
                end_time: endTime + ':00',
                purpose: purpose,
                status: 'pending'
            })
        });

        if (response.ok) {
            showAlert('Pemesanan berhasil dibuat', 'success');
            bootstrap.Modal.getInstance(document.getElementById('addBookingModal')).hide();
            loadBookings();
        } else {
            const error = await response.text();
            showAlert(`Gagal membuat pemesanan: ${error}`, 'danger');
        }
    } catch (error) {
        console.error('Error saving booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

async function approveBooking(id) {
    try {
        const response = await fetch(`${API_BASE}/bookings/${id}?action=approve`, { method: 'POST' });
        if (response.ok) {
            showAlert('Pemesanan disetujui', 'success');
            loadBookings();
        } else {
            showAlert('Gagal menyetujui pemesanan', 'danger');
        }
    } catch (error) {
        console.error('Error approving booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

async function rejectBooking(id) {
    try {
        const response = await fetch(`${API_BASE}/bookings/${id}?action=reject`, { method: 'POST' });
        if (response.ok) {
            showAlert('Pemesanan ditolak', 'success');
            loadBookings();
        } else {
            showAlert('Gagal menolak pemesanan', 'danger');
        }
    } catch (error) {
        console.error('Error rejecting booking:', error);
        showAlert('Terjadi kesalahan', 'danger');
    }
}

// ==================== Reports ====================

function setCurrentMonth() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    document.getElementById('report-month').value = `${year}-${month}`;
}

async function generateReport() {
    const monthStr = document.getElementById('report-month').value;
    if (!monthStr) {
        showAlert('Pilih bulan terlebih dahulu', 'warning');
        return;
    }

    const [year, month] = monthStr.split('-');
    const statusDiv = document.getElementById('report-status');
    statusDiv.innerHTML = '<small class="text-muted">Generating...</small>';

    try {
        const response = await fetch(`${API_BASE}/report?year=${year}&month=${month}`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json() || {};
        statusDiv.innerHTML = `
                <div class="alert alert-success mt-2">
                    <strong>✓ Laporan berhasil dibuat!</strong><br>
                    <small>
                        📄 ${data.json}<br>
                        📊 ${data.csv}
                    </small>
                </div>
            `;
        showAlert('Laporan berhasil dibuat', 'success');
    } catch (error) {
        console.error('Error generating report:', error);
        console.error('URL:', `${API_BASE}/report?year=${year}&month=${month}`);
        showAlert(`Gagal membuat laporan: ${error.message}`, 'danger');
        statusDiv.innerHTML = '';
    }
}

// ==================== Utilities ====================

function formatStatus(status) {
    const statuses = {
        'pending': 'Menunggu',
        'approved': 'Disetujui',
        'rejected': 'Ditolak'
    };
    return statuses[status] || status;
}

function showAlert(message, type = 'info') {
    const alertId = 'alert-' + Date.now();
    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show position-fixed" 
             style="top: 80px; right: 20px; z-index: 9999; min-width: 300px;" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    const container = document.getElementById('alert-container');
    container.insertAdjacentHTML('beforeend', alertHTML);

    setTimeout(() => {
        const element = document.getElementById(alertId);
        if (element) {
            element.remove();
        }
    }, 5000);
}
