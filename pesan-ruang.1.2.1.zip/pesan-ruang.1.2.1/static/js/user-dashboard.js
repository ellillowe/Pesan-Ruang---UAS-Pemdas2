const API = 'http://localhost:8080';
let currentUser = null;
let selectedRoomId = null;

document.addEventListener('DOMContentLoaded', () => {
    currentUser = checkAuth();
    if (!currentUser || currentUser.role === 'admin') {
        window.location.href = '/login.html';
        return;
    }
    document.getElementById('user-name').textContent = currentUser.name;
    loadDashboard();
    loadRoomsGrid();
    loadMyBookings();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = localStorage.getItem('current_user');
    if (!token || !user) window.location.href = '/login.html';
    return JSON.parse(user);
}

function logout() {
    localStorage.clear();
    window.location.href = '/login.html';
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) {
            logout();
        }
        throw new Error(await res.text());
    }
    return res.json();
}

// Dashboard
async function loadDashboard() {
    try {
        const rooms = await apiCall('/rooms');
        const bookings = await apiCall('/bookings');
        const myBookings = (bookings || []).filter(b => b.user_id === currentUser.id);
        
        document.getElementById('total-rooms').textContent = (rooms || []).filter(r => r.is_active).length;
        document.getElementById('approved-bookings').textContent = myBookings.filter(b => b.status === 'approved').length;
        document.getElementById('pending-bookings').textContent = myBookings.filter(b => b.status === 'pending').length;
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

// Rooms Grid
async function loadRoomsGrid() {
    try {
        const rooms = await apiCall('/rooms');
        const grid = document.getElementById('rooms-grid');
        grid.innerHTML = '';
        (rooms || []).filter(r => r.is_active).forEach(r => {
            grid.innerHTML += `
                <div class="col-md-6 col-lg-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">${r.name}</h5>
                            <p>
                                <strong>Tipe:</strong> <span class="badge bg-info">${r.type}</span><br>
                                <strong>Kapasitas:</strong> ${r.capacity} orang
                            </p>
                            <button class="btn btn-primary w-100" onclick="openBookingModal(${r.id}, '${r.name}')">
                                <i class="bi bi-calendar-plus"></i> Pesan
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

function openBookingModal(roomId, roomName) {
    selectedRoomId = roomId;
    document.getElementById('booking-room-name').textContent = roomName;
    document.getElementById('booking-date').value = '';
    document.getElementById('booking-start').value = '';
    document.getElementById('booking-end').value = '';
    document.getElementById('booking-purpose').value = '';
    new bootstrap.Modal(document.getElementById('bookingModal')).show();
}

async function saveBooking() {
    try {
        const date = document.getElementById('booking-date').value;
        const startTime = document.getElementById('booking-start').value;
        const endTime = document.getElementById('booking-end').value;
        const purpose = document.getElementById('booking-purpose').value;

        if (!date || !startTime || !endTime || !purpose) {
            showAlert('Semua field harus diisi', 'warning');
            return;
        }

        await apiCall('/bookings', 'POST', {
            room_id: selectedRoomId,
            user_id: currentUser.id,
            date,
            start_time: startTime,
            end_time: endTime,
            purpose,
            status: 'pending'
        });

        showAlert('Pemesanan berhasil dibuat', 'success');
        bootstrap.Modal.getInstance(document.getElementById('bookingModal')).hide();
        loadDashboard();
        loadMyBookings();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

// My Bookings
async function loadMyBookings() {
    try {
        const bookings = await apiCall('/bookings');
        const rooms = await apiCall('/rooms');
        const tbody = document.getElementById('my-bookings');
        tbody.innerHTML = '';
        const myBookings = (bookings || []).filter(b => b.user_id === currentUser.id);
        myBookings.forEach((b, i) => {
            const room = (rooms || []).find(r => r.id === b.room_id);
            const statusBadge = {
                'pending': '<span class="badge bg-warning">Pending</span>',
                'approved': '<span class="badge bg-success">Disetujui</span>',
                'rejected': '<span class="badge bg-danger">Ditolak</span>'
            }[b.status] || b.status;
            tbody.innerHTML += `
                <tr>
                    <td>${i + 1}</td>
                    <td>${room?.name || 'Unknown'}</td>
                    <td>${b.date}</td>
                    <td>${b.start_time} - ${b.end_time}</td>
                    <td>${b.purpose}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${b.status === 'pending' ? `
                            <button class="btn btn-sm btn-danger" onclick="cancelBooking(${b.id})">Batal</button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
        if (myBookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada pemesanan</td></tr>';
        }
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

async function cancelBooking(id) {
    if (!confirm('Batal pemesanan ini?')) return;
    try {
        await apiCall(`/bookings/${id}?action=reject`, 'POST');
        showAlert('Pemesanan dibatalkan', 'success');
        loadMyBookings();
        loadDashboard();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
