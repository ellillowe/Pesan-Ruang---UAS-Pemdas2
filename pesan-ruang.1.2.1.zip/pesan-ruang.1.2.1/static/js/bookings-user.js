const API = 'http://localhost:8080';
let currentUser = null;
let currentFilter = 'pending';

document.addEventListener('DOMContentLoaded', () => {
    currentUser = checkAuth();
    loadMyBookings();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    if (!token || user.role === 'admin') {
        window.location.href = '/login.html';
    }
    return user;
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) location.href = '/login.html';
        throw new Error(await res.text());
    }
    return res.json();
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function loadMyBookings() {
    try {
        const bookings = await apiCall('/bookings');
        const rooms = await apiCall('/rooms');
        const tbody = document.getElementById('bookings-list');
        tbody.innerHTML = '';

        const myBookings = (bookings || []).filter(b => b.user_id === currentUser.id && b.status === currentFilter);
        const roomsMap = {};
        (rooms || []).forEach(r => roomsMap[r.id] = r.name);

        myBookings.forEach((b, i) => {
            const statusBadge = {
                'pending': '<span class="badge bg-warning">Pending</span>',
                'approved': '<span class="badge bg-success">Disetujui</span>',
                'rejected': '<span class="badge bg-danger">Ditolak</span>'
            }[b.status] || b.status;

            tbody.innerHTML += `
                <tr>
                    <td>${i + 1}</td>
                    <td>${roomsMap[b.room_id] || 'Unknown'}</td>
                    <td>${b.date}</td>
                    <td>${b.start_time} - ${b.end_time}</td>
                    <td>${b.purpose}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${b.status === 'pending' ? `
                            <button class="btn btn-sm btn-danger" onclick="cancelBooking(${b.id})">Batal</button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });

        if (myBookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Tidak ada pemesanan</td></tr>';
        }
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

function filterBookings(status) {
    currentFilter = status;
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    document.getElementById(status + '-tab').classList.add('active');
    loadMyBookings();
}

async function cancelBooking(id) {
    if (!confirm('Batal pemesanan ini?')) return;
    try {
        await apiCall(`/bookings/${id}?action=reject`, 'POST');
        showAlert('Pemesanan dibatalkan', 'success');
        loadMyBookings();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
