const API = 'http://localhost:8080';
let currentUser = null;
let selectedRoomId = null;
let allRooms = [];

document.addEventListener('DOMContentLoaded', () => {
    currentUser = checkAuth();
    loadRoomsGrid();
});

function checkAuth() {
    const token = localStorage.getItem('auth_token');
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    if (!token || user.role === 'admin') {
        window.location.href = '/login.html';
    }
    return user;
}

async function apiCall(path, method = 'GET', body = null) {
    const token = localStorage.getItem('auth_token');
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + path, opts);
    if (!res.ok) {
        if (res.status === 401) location.href = '/login.html';
        throw new Error(await res.text());
    }
    return res.json();
}

function showAlert(msg, type = 'success') {
    const div = document.createElement('div');
    div.className = `alert alert-${type}`;
    div.textContent = msg;
    document.getElementById('alert-container').innerHTML = '';
    document.getElementById('alert-container').appendChild(div);
}

async function loadRoomsGrid() {
    try {
        const rooms = await apiCall('/rooms');
        allRooms = (rooms || []).filter(r => r.is_active);
        displayRoomsGrid(allRooms);
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}

function displayRoomsGrid(rooms) {
    const grid = document.getElementById('rooms-grid');
    grid.innerHTML = '';
    
    if (rooms.length === 0) {
        grid.innerHTML = '<div class="col-12"><div class="alert alert-info">Tidak ada ruang ditemukan</div></div>';
        return;
    }
    
    rooms.forEach(r => {
        grid.innerHTML += `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">${r.name}</h5>
                        <p class="card-text">
                            <small>
                                <strong>Tipe:</strong> <span class="badge bg-info">${r.type}</span><br>
                                <strong>Kapasitas:</strong> ${r.capacity} orang
                            </small>
                        </p>
                        <button class="btn btn-primary w-100" onclick="openBookingModal(${r.id}, '${r.name}')">
                            <i class="bi bi-calendar-plus"></i> Pesan Ruang
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
}

function filterRoomsGrid() {
    const searchTerm = document.getElementById('search-room').value.toLowerCase();
    const filtered = allRooms.filter(room => 
        room.name.toLowerCase().includes(searchTerm)
    );
    displayRoomsGrid(filtered);
}

function openBookingModal(roomId, roomName) {
    selectedRoomId = roomId;
    document.getElementById('booking-room-id').value = roomId;
    document.getElementById('booking-room-name').textContent = roomName;
    document.getElementById('booking-date').value = '';
    document.getElementById('booking-start').value = '';
    document.getElementById('booking-end').value = '';
    document.getElementById('booking-purpose').value = '';
    new bootstrap.Modal(document.getElementById('bookingModal')).show();
}

async function saveBooking() {
    try {
        const date = document.getElementById('booking-date').value;
        const startTime = document.getElementById('booking-start').value;
        const endTime = document.getElementById('booking-end').value;
        const purpose = document.getElementById('booking-purpose').value;

        if (!date || !startTime || !endTime || !purpose) {
            showAlert('Semua field harus diisi', 'warning');
            return;
        }

        await apiCall('/bookings', 'POST', {
            room_id: selectedRoomId,
            user_id: currentUser.id,
            date, start_time: startTime, end_time: endTime,
            purpose, status: 'pending'
        });

        showAlert('Pemesanan berhasil dibuat', 'success');
        bootstrap.Modal.getInstance(document.getElementById('bookingModal')).hide();
    } catch (e) {
        showAlert('Error: ' + e.message, 'danger');
    }
}
