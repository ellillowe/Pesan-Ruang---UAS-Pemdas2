// Show/hide navigation based on user role
function initSidebar() {
    const user = JSON.parse(localStorage.getItem('current_user') || '{}');
    const adminNav = document.getElementById('admin-nav');
    const userNav = document.getElementById('user-nav');
    const userEmail = document.getElementById('user-email');

    if (user.role === 'admin') {
        adminNav.style.display = 'block';
        userNav.style.display = 'none';
    } else {
        adminNav.style.display = 'none';
        userNav.style.display = 'block';
    }

    userEmail.textContent = user.email || 'Unknown';
}

// Mark current page as active
function markActivePage() {
    const currentPage = window.location.pathname;
    document.querySelectorAll('.nav-link').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

function logout() {
    localStorage.clear();
    window.location.href = '/login.html';
}

// Make logout global
window.logout = logout;
