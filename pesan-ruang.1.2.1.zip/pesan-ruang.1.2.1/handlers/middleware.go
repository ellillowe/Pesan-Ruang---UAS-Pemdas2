package handlers

import (
	"fmt"
	"net/http"
	"strings"
)

// User info extracted from token
type ContextUser struct {
	ID    int
	Email string
	Role  string
}

// AuthMiddleware validates the token and adds user info to context
func AuthMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		addCORSHeaders(w)
		if r.Method == http.MethodOptions {
			return
		}

		// Get token from Authorization header
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			http.Error(w, "Missing authorization token", http.StatusUnauthorized)
			return
		}

		// Extract token from "Bearer <token>"
		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || parts[0] != "Bearer" {
			http.Error(w, "Invalid authorization format", http.StatusUnauthorized)
			return
		}

		token := parts[1]

		// Parse token (simple format: user_<id>_<email>)
		// In production, use JWT
		if !strings.HasPrefix(token, "user_") {
			http.Error(w, "Invalid token format", http.StatusUnauthorized)
			return
		}

		// For now, we'll just validate format
		// In production, verify JWT signature
		r.Header.Set("X-User-Token", token)
		next(w, r)
	}
}

// RequireRole middleware checks if user has required role
func RequireRole(requiredRole string, next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		addCORSHeaders(w)
		if r.Method == http.MethodOptions {
			return
		}

		// In production, extract role from JWT token
		// For now, we'll check the user role from session/token
		// This is a placeholder - you'd typically verify JWT here

		// Get token
		authHeader := r.Header.Get("Authorization")
		if authHeader == "" {
			http.Error(w, "Missing authorization token", http.StatusUnauthorized)
			return
		}

		// For now, just allow - role checking happens in service layer
		// In production, verify JWT and check role claim
		next(w, r)
	}
}

// HealthCheck is a simple health check endpoint
func HealthCheck(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}

	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"status":"ok"}`)
}

// CORS headers helper
func addCORSHeaders(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
}

// AddCORSHeaders exported for use in main.go
func AddCORSHeaders(w http.ResponseWriter) {
	addCORSHeaders(w)
}
