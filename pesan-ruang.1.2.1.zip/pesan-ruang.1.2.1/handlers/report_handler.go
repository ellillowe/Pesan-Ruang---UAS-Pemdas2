package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// ReportHandler handles report-related HTTP requests
type ReportHandler struct{}

// NewReportHandler creates a new report handler
func NewReportHandler() *ReportHandler {
	return &ReportHandler{}
}

// DownloadReport downloads a specific report file
func (h *ReportHandler) DownloadReport(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Extract filename from URL path
	parts := strings.Split(r.URL.Path, "/")
	if len(parts) < 3 {
		http.Error(w, "Invalid URL path", http.StatusBadRequest)
		return
	}

	filename := parts[len(parts)-1]

	// Security: validate filename to prevent directory traversal
	if strings.Contains(filename, "..") || strings.Contains(filename, "/") {
		http.Error(w, "Invalid filename", http.StatusBadRequest)
		return
	}

	// Only allow .json and .csv files
	if !strings.HasSuffix(filename, ".json") && !strings.HasSuffix(filename, ".csv") {
		http.Error(w, "Invalid file type", http.StatusBadRequest)
		return
	}

	// Build full file path
	filepath := filepath.Join("reports", filename)

	// Check if file exists
	if _, err := os.Stat(filepath); err != nil {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}

	// Set appropriate content type
	if strings.HasSuffix(filename, ".json") {
		w.Header().Set("Content-Type", "application/json")
	} else if strings.HasSuffix(filename, ".csv") {
		w.Header().Set("Content-Type", "text/csv")
		w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", filename))
	}

	// Serve file
	http.ServeFile(w, r, filepath)
}

// ListReports lists all available report files
func (h *ReportHandler) ListReports(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	reportsDir := "reports"

	// Create reports directory if not exists
	os.MkdirAll(reportsDir, 0755)

	// List files in reports directory
	entries, err := os.ReadDir(reportsDir)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to list reports: %v", err), http.StatusInternalServerError)
		return
	}

	var files []map[string]interface{}
	for _, entry := range entries {
		if !entry.IsDir() {
			info, _ := entry.Info()
			files = append(files, map[string]interface{}{
				"name":     entry.Name(),
				"size":     info.Size(),
				"modified": info.ModTime().Format("2006-01-02 15:04:05"),
				"url":      fmt.Sprintf("/download/laporan/%s", entry.Name()),
			})
		}
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	if files == nil {
		files = []map[string]interface{}{}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"files": files,
	})
}
