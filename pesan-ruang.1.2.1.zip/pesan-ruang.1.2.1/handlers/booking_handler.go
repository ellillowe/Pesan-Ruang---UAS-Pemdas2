package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"pesan-ruang/models"
	"pesan-ruang/services"
	"strconv"
	"strings"
	"time"
)

// BookingHandler handles booking-related HTTP requests
type BookingHandler struct {
	bookingService *services.BookingService
}

// NewBookingHandler creates a new booking handler
func NewBookingHandler(bookingService *services.BookingService) *BookingHandler {
	return &BookingHandler{bookingService: bookingService}
}

// GetBookings retrieves bookings (all or filtered by user)
func (h *BookingHandler) GetBookings(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	w.Header().Set("Content-Type", "application/json")

	bookings, err := h.bookingService.GetAllBookings()
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to retrieve bookings: %v", err), http.StatusInternalServerError)
		return
	}

	if bookings == nil {
		bookings = []models.Booking{}
	}

	json.NewEncoder(w).Encode(bookings)
}

// CreateBooking creates a new booking
func (h *BookingHandler) CreateBooking(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var booking models.Booking
	if err := json.NewDecoder(r.Body).Decode(&booking); err != nil {
		http.Error(w, fmt.Sprintf("Invalid request body: %v", err), http.StatusBadRequest)
		return
	}

	id, err := h.bookingService.CreateBooking(&booking)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to create booking: %v", err), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(map[string]int{"id": id})
}

// ApproveBooking approves a pending booking
func (h *BookingHandler) ApproveBooking(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	parts := strings.Split(r.URL.Path, "/")
	if len(parts) < 3 {
		http.Error(w, "Invalid URL path", http.StatusBadRequest)
		return
	}

	bookingID, err := strconv.Atoi(parts[2])
	if err != nil {
		http.Error(w, "Invalid booking ID", http.StatusBadRequest)
		return
	}

	if err := h.bookingService.ApproveBooking(bookingID); err != nil {
		http.Error(w, fmt.Sprintf("Failed to approve booking: %v", err), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": "Booking approved successfully"})
}

// RejectBooking rejects a booking
func (h *BookingHandler) RejectBooking(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	parts := strings.Split(r.URL.Path, "/")
	if len(parts) < 3 {
		http.Error(w, "Invalid URL path", http.StatusBadRequest)
		return
	}

	bookingID, err := strconv.Atoi(parts[2])
	if err != nil {
		http.Error(w, "Invalid booking ID", http.StatusBadRequest)
		return
	}

	if err := h.bookingService.RejectBooking(bookingID); err != nil {
		http.Error(w, fmt.Sprintf("Failed to reject booking: %v", err), http.StatusBadRequest)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": "Booking rejected successfully"})
}

// GetMonthlyReport generates a monthly report
func (h *BookingHandler) GetMonthlyReport(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Get query parameters for year and month
	yearStr := r.URL.Query().Get("year")
	monthStr := r.URL.Query().Get("month")

	if yearStr == "" || monthStr == "" {
		// Use current year and month if not provided
		now := time.Now()
		yearStr = fmt.Sprintf("%d", now.Year())
		monthStr = fmt.Sprintf("%d", now.Month())
	}

	year, err := strconv.Atoi(yearStr)
	if err != nil {
		http.Error(w, "Invalid year parameter", http.StatusBadRequest)
		return
	}

	month, err := strconv.Atoi(monthStr)
	if err != nil {
		http.Error(w, "Invalid month parameter", http.StatusBadRequest)
		return
	}

	if month < 1 || month > 12 {
		http.Error(w, "Invalid month (must be 1-12)", http.StatusBadRequest)
		return
	}

	// Get report summary with timeout handling
	summary, err := h.bookingService.GetReportSummary(year, month)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to get report summary: %v", err), http.StatusInternalServerError)
		return
	}

	// Handle nil summary
	if summary == nil {
		summary = []services.ReportSummary{}
	}

	// Save to JSON file
	jsonFilename := fmt.Sprintf("laporan_%04d%02d.json", year, month)
	jsonPath := filepath.Join("reports", jsonFilename)
	saveReportToJSON(summary, year, month, jsonPath)

	// Save to CSV file
	csvFilename := fmt.Sprintf("laporan_%04d%02d.csv", year, month)
	csvPath := filepath.Join("reports", csvFilename)
	saveReportToCSV(summary, year, month, csvPath)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"message": fmt.Sprintf("Report generated for %04d-%02d", year, month),
		"summary": summary,
		"files": map[string]string{
			"json": jsonFilename,
			"csv":  csvFilename,
		},
	})
}

// GetPendingApprovals returns count of pending bookings
func (h *BookingHandler) GetPendingApprovals(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	bookings, err := h.bookingService.GetAllBookings()
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to retrieve bookings: %v", err), http.StatusInternalServerError)
		return
	}

	pendingCount := 0
	var pendingBookings []map[string]interface{}

	for _, booking := range bookings {
		if booking.Status == "pending" {
			pendingCount++
			pendingBookings = append(pendingBookings, map[string]interface{}{
				"id":         booking.ID,
				"room_id":    booking.RoomID,
				"user_id":    booking.UserID,
				"date":       booking.Date,
				"start_time": booking.StartTime,
				"end_time":   booking.EndTime,
			})
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"pending_count":    pendingCount,
		"pending_bookings": pendingBookings,
	})
}

// GetAnalyticsStats returns statistics for dashboard
func (h *BookingHandler) GetAnalyticsStats(w http.ResponseWriter, r *http.Request) {
	addCORSHeaders(w)
	if r.Method == http.MethodOptions {
		return
	}
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	bookings, err := h.bookingService.GetAllBookings()
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to retrieve bookings: %v", err), http.StatusInternalServerError)
		return
	}

	// Count by status
	statusCount := make(map[string]int)
	for _, booking := range bookings {
		statusCount[booking.Status]++
	}

	// Monthly stats
	monthlyStats := make(map[string]int)
	for _, booking := range bookings {
		if booking.Status != "rejected" {
			bookingDate, err := time.Parse("2006-01-02", booking.Date)
			if err != nil {
				continue
			}
			monthKey := fmt.Sprintf("%04d-%02d", bookingDate.Year(), bookingDate.Month())
			monthlyStats[monthKey]++
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"total_bookings":   len(bookings),
		"status_breakdown": statusCount,
		"monthly_bookings": monthlyStats,
	})
}

// saveReportToJSON saves report summary to JSON file
func saveReportToJSON(summary []services.ReportSummary, year, month int, filepath string) error {
	// Create reports directory if not exists
	os.MkdirAll("reports", 0755)

	reportData := map[string]interface{}{
		"generated_at": time.Now().Format(time.RFC3339),
		"period":       fmt.Sprintf("%04d-%02d", year, month),
		"summary":      summary,
	}

	jsonBytes, err := json.MarshalIndent(reportData, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal JSON: %w", err)
	}

	return os.WriteFile(filepath, jsonBytes, 0644)
}

// saveReportToCSV saves report summary to CSV file
func saveReportToCSV(summary []services.ReportSummary, year, month int, filepath string) error {
	// Create reports directory if not exists
	os.MkdirAll("reports", 0755)

	// CSV headers
	csv := "No,Nama Ruang,Total Pemesanan,Total Waktu Pemesanan\n"

	// CSV data
	for i, item := range summary {
		csv += fmt.Sprintf("%d,%s,%d,%s\n",
			i+1,
			item.RoomName,
			item.TotalBookings,
			item.TotalWaktuPemesanan,
		)
	}

	return os.WriteFile(filepath, []byte(csv), 0644)
}
