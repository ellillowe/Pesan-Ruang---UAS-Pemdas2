package handlers

import (
	"bytes"
	"encoding/json"
	"net/http"
	"testing"
)

// TestBookingHandlerMethodValidation tests HTTP method validation
func TestBookingHandlerMethodValidation(t *testing.T) {
	tests := []struct {
		name       string
		method     string
		path       string
		shouldFail bool
	}{
		{
			name:       "GET /bookings allowed",
			method:     "GET",
			path:       "/bookings",
			shouldFail: false,
		},
		{
			name:       "POST /bookings allowed",
			method:     "POST",
			path:       "/bookings",
			shouldFail: false,
		},
		{
			name:       "DELETE /bookings not allowed",
			method:     "DELETE",
			path:       "/bookings",
			shouldFail: true,
		},
		{
			name:       "PUT /bookings not allowed",
			method:     "PUT",
			path:       "/bookings",
			shouldFail: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := http.NewRequest(tt.method, tt.path, nil)
			if err != nil {
				t.Fatal(err)
			}

			// Validate method
			isValidMethod := (tt.method == "GET" || tt.method == "POST") && tt.path == "/bookings"

			if tt.shouldFail && isValidMethod {
				t.Errorf("expected to fail but method was valid")
			}
			if !tt.shouldFail && !isValidMethod {
				t.Errorf("expected to succeed but method was invalid")
			}
		})
	}
}

// TestBookingHandlerRequestValidation tests booking request validation
func TestBookingHandlerRequestValidation(t *testing.T) {
	tests := []struct {
		name      string
		roomID    int
		userID    int
		date      string
		startTime string
		endTime   string
		shouldErr bool
	}{
		{
			name:      "Valid booking request",
			roomID:    1,
			userID:    1,
			date:      "2026-01-20",
			startTime: "08:00",
			endTime:   "09:00",
			shouldErr: false,
		},
		{
			name:      "Missing roomID",
			roomID:    0,
			userID:    1,
			date:      "2026-01-20",
			startTime: "08:00",
			endTime:   "09:00",
			shouldErr: true,
		},
		{
			name:      "Missing userID",
			roomID:    1,
			userID:    0,
			date:      "2026-01-20",
			startTime: "08:00",
			endTime:   "09:00",
			shouldErr: true,
		},
		{
			name:      "Empty startTime",
			roomID:    1,
			userID:    1,
			date:      "2026-01-20",
			startTime: "",
			endTime:   "09:00",
			shouldErr: true,
		},
		{
			name:      "Empty endTime",
			roomID:    1,
			userID:    1,
			date:      "2026-01-20",
			startTime: "08:00",
			endTime:   "",
			shouldErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			booking := map[string]interface{}{
				"room_id":    tt.roomID,
				"user_id":    tt.userID,
				"date":       tt.date,
				"start_time": tt.startTime,
				"end_time":   tt.endTime,
			}

			// Validate required fields
			isValid := tt.roomID > 0 && tt.userID > 0 &&
				tt.date != "" && tt.startTime != "" && tt.endTime != ""

			if isValid == tt.shouldErr {
				t.Errorf("validation mismatch: expected error=%v, got valid=%v", tt.shouldErr, isValid)
			}

			body, _ := json.Marshal(booking)
			_, err := http.NewRequest("POST", "/bookings", bytes.NewReader(body))
			if err != nil {
				t.Fatal(err)
			}
		})
	}
}

// TestBookingHandlerReportParameters tests report query parameters validation
func TestBookingHandlerReportParameters(t *testing.T) {
	tests := []struct {
		name  string
		month string
		year  string
		valid bool
	}{
		{
			name:  "Valid month and year",
			month: "1",
			year:  "2026",
			valid: true,
		},
		{
			name:  "Missing month",
			month: "",
			year:  "2026",
			valid: false,
		},
		{
			name:  "Missing year",
			month: "1",
			year:  "",
			valid: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, err := http.NewRequest("GET", "/reports/monthly?month="+tt.month+"&year="+tt.year, nil)
			if err != nil {
				t.Fatal(err)
			}

			// Validate parameters
			monthVal := req.URL.Query().Get("month")
			yearVal := req.URL.Query().Get("year")

			hasParams := monthVal != "" && yearVal != ""
			if hasParams != tt.valid {
				t.Errorf("parameter validation failed")
			}
		})
	}
}

// TestBookingHandlerJSONParsing tests JSON parsing in requests
func TestBookingHandlerJSONParsing(t *testing.T) {
	tests := []struct {
		name      string
		jsonBody  string
		shouldErr bool
	}{
		{
			name: "Valid JSON",
			jsonBody: `{
				"room_id": 1,
				"user_id": 1,
				"date": "2026-01-20",
				"start_time": "08:00",
				"end_time": "09:00"
			}`,
			shouldErr: false,
		},
		{
			name:      "Invalid JSON - missing closing brace",
			jsonBody:  `{"room_id": 1, "user_id": 1`,
			shouldErr: true,
		},
		{
			name:      "Invalid JSON - invalid string",
			jsonBody:  `{"room_id": 1, "name": 'invalid'}`,
			shouldErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, err := http.NewRequest("POST", "/bookings", bytes.NewReader([]byte(tt.jsonBody)))
			if err != nil {
				t.Fatal(err)
			}
			req.Header.Set("Content-Type", "application/json")

			var data map[string]interface{}
			err = json.NewDecoder(req.Body).Decode(&data)

			if tt.shouldErr && err == nil {
				t.Errorf("expected JSON parsing error")
			}
			if !tt.shouldErr && err != nil {
				t.Errorf("unexpected JSON parsing error: %v", err)
			}
		})
	}
}
