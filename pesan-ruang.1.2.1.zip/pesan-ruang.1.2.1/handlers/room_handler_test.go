package handlers

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

// TestRoomHandlerMethodValidation tests HTTP method validation for room endpoints
func TestRoomHandlerMethodValidation(t *testing.T) {
	tests := []struct {
		name       string
		method     string
		path       string
		shouldWork bool
	}{
		{
			name:       "GET /rooms allowed",
			method:     "GET",
			path:       "/rooms",
			shouldWork: true,
		},
		{
			name:       "POST /rooms allowed",
			method:     "POST",
			path:       "/rooms",
			shouldWork: true,
		},
		{
			name:       "DELETE /rooms not allowed",
			method:     "DELETE",
			path:       "/rooms",
			shouldWork: false,
		},
		{
			name:       "GET /rooms/1 allowed",
			method:     "GET",
			path:       "/rooms/1",
			shouldWork: true,
		},
		{
			name:       "PUT /rooms/1 allowed",
			method:     "PUT",
			path:       "/rooms/1",
			shouldWork: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := http.NewRequest(tt.method, tt.path, nil)
			if err != nil {
				t.Fatal(err)
			}

			// Validate method logic
			isValidListMethod := (tt.method == "GET" || tt.method == "POST") && tt.path == "/rooms"
			isValidDetailMethod := (tt.method == "GET" || tt.method == "PUT") && tt.path == "/rooms/1"

			isValid := isValidListMethod || isValidDetailMethod

			if isValid != tt.shouldWork {
				t.Errorf("expected work=%v, but got %v", tt.shouldWork, isValid)
			}
		})
	}
}

// TestRoomHandlerRequestValidation tests room creation/update request validation
func TestRoomHandlerRequestValidation(t *testing.T) {
	tests := []struct {
		name      string
		name_     string
		roomType  string
		capacity  int
		shouldErr bool
	}{
		{
			name:      "Valid classroom",
			name_:     "Ruang A101",
			roomType:  "kelas",
			capacity:  40,
			shouldErr: false,
		},
		{
			name:      "Valid lab",
			name_:     "Lab Komputer 1",
			roomType:  "lab",
			capacity:  30,
			shouldErr: false,
		},
		{
			name:      "Missing name",
			name_:     "",
			roomType:  "kelas",
			capacity:  40,
			shouldErr: true,
		},
		{
			name:      "Invalid room type",
			name_:     "Ruang B101",
			roomType:  "invalid",
			capacity:  40,
			shouldErr: true,
		},
		{
			name:      "Zero capacity",
			name_:     "Ruang C101",
			roomType:  "kelas",
			capacity:  0,
			shouldErr: true,
		},
		{
			name:      "Negative capacity",
			name_:     "Ruang D101",
			roomType:  "kelas",
			capacity:  -10,
			shouldErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			room := map[string]interface{}{
				"name":     tt.name_,
				"type":     tt.roomType,
				"capacity": tt.capacity,
			}

			// Validate room data
			isValid := tt.name_ != "" &&
				(tt.roomType == "kelas" || tt.roomType == "lab") &&
				tt.capacity > 0

			if isValid == tt.shouldErr {
				t.Errorf("validation mismatch: expected error=%v, got valid=%v", tt.shouldErr, isValid)
			}

			body, _ := json.Marshal(room)
			req, err := http.NewRequest("POST", "/rooms", bytes.NewReader(body))
			if err != nil {
				t.Fatal(err)
			}
			req.Header.Set("Content-Type", "application/json")

			w := httptest.NewRecorder()
			_ = w
		})
	}
}

// TestRoomHandlerJSONParsing tests JSON parsing in requests
func TestRoomHandlerJSONParsing(t *testing.T) {
	tests := []struct {
		name      string
		jsonBody  string
		shouldErr bool
	}{
		{
			name: "Valid JSON",
			jsonBody: `{
				"name": "Ruang A101",
				"type": "kelas",
				"capacity": 40,
				"is_active": true
			}`,
			shouldErr: false,
		},
		{
			name:      "Invalid JSON - missing closing brace",
			jsonBody:  `{"name": "Ruang A101", "type": "kelas"`,
			shouldErr: true,
		},
		{
			name:      "Invalid JSON - bad string",
			jsonBody:  `{"name": 'invalid', "type": "kelas"}`,
			shouldErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req, err := http.NewRequest("POST", "/rooms", bytes.NewReader([]byte(tt.jsonBody)))
			if err != nil {
				t.Fatal(err)
			}
			req.Header.Set("Content-Type", "application/json")

			var data map[string]interface{}
			err = json.NewDecoder(req.Body).Decode(&data)

			if tt.shouldErr && err == nil {
				t.Errorf("expected JSON parsing error")
			}
			if !tt.shouldErr && err != nil {
				t.Errorf("unexpected JSON parsing error: %v", err)
			}
		})
	}
}

// TestRoomHandlerRoomTypes tests room type validation
func TestRoomHandlerRoomTypes(t *testing.T) {
	validTypes := []string{"kelas", "lab"}
	invalidTypes := []string{"invalid", "other", "kantor", ""}

	for _, roomType := range validTypes {
		t.Run("Valid type: "+roomType, func(t *testing.T) {
			isValid := false
			for _, vt := range validTypes {
				if roomType == vt {
					isValid = true
					break
				}
			}
			if !isValid {
				t.Errorf("type '%s' should be valid", roomType)
			}
		})
	}

	for _, roomType := range invalidTypes {
		t.Run("Invalid type: "+roomType, func(t *testing.T) {
			isValid := false
			for _, vt := range validTypes {
				if roomType == vt {
					isValid = true
					break
				}
			}
			if isValid {
				t.Errorf("type '%s' should be invalid", roomType)
			}
		})
	}
}

// TestRoomHandlerCapacityValidation tests room capacity validation
func TestRoomHandlerCapacityValidation(t *testing.T) {
	tests := []struct {
		name     string
		capacity int
		valid    bool
	}{
		{"Capacity 1", 1, true},
		{"Capacity 10", 10, true},
		{"Capacity 100", 100, true},
		{"Capacity 500", 500, true},
		{"Capacity 0", 0, false},
		{"Capacity -1", -1, false},
		{"Capacity -100", -100, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			isValid := tt.capacity > 0
			if isValid != tt.valid {
				t.Errorf("capacity %d: expected valid=%v, got %v", tt.capacity, tt.valid, isValid)
			}
		})
	}
}
